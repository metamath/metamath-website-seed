module Hmm
	(
	,Database
	,mmParseFromFile,mmParseFromString
	,mmVerifiesProof,mmVerifiesLabel,mmVerifiesDatabase,mmVerifiesAll
	)

where

import HmmImpl
