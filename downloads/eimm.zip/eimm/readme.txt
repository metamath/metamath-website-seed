Export/import between mmj2 worksheets and Metamath's MM-PA

23-Oct-2006  Norman Megill

*** You must use Metamath 0.07.27 or later with this package ***

There is ongoing discussion about this program here:
http://planetx.cc.vt.edu/AsteroidMeta/mmj2ProofAssistantFeedback
under "Case 5a" and "Case 5b".

This package contains 5 files:

  eimmexp.cmd - command file to run inside of the Metamath program, that
      exports a proof in progress to an mmj2 worksheet (mmp) file.
  eimmimp.cmd - command file to run inside of the Metamath program, that
      imports an mmj2 proof worksheet into the Proof Assistant.
  eimm.c - the export/import program - normally run via the command files
      above.  Type "eimm --help" for instructions on how to run it
      directly.  For non-Windows machines, compile with
      "gcc eimm.c -o eimm".
  eimm.exe - a pre-compiled version of eimm.c for Windows users
  readme.txt - this file

Quick start for Windows:  put eimmexp.cmd, eimmimp.cmd, and eimm.exe
into your local directory (the one you are running metamath.exe from).


Quick overview:

  Metamath program's Proof Assistant (MM-PA> prompt)
                  |            ^
                  |            |
    submit eimmexp.cmd /s   submit eimmimp.cmd /s
                  |            |
                  v            |
           [*.mmp proof worksheet file]
                  |            ^
                  |            |
              File/Open    File/Save
                  |            |
                  v            |
             mmj2 GUI Proof Assistant



Flowchart of overall proof-building process, using eimm:

  text editor - add new theorem with "?" in place of proof
            ^
            |
            |
            v
  *.mm file (Metamath database)
       |         ^
       |         |
     read     write source
       |         |
       v         |
  Metamath program (metamath.exe)
       |         ^
       |         |
    prove  save new_proof
       |         |
       v         |
  Metamath program's MM-PA
       |             ^
       |             |
    eimmexp.cmd  eimmimp.cmd      <- type 'submit eimmexp.cmd / silent'
       |             |               or 'su eimmexp.cmd/s' abbreviated at
       v             |               the MM-PA prompt; same for eimmimp.cmd
  *.mmp file (proof worksheet)
       |          ^
       |          |
    File/Open  File/Save
       |          |
       v          |
  mmj2 GUI PA (C:\mmj2\test\windows\RunPAGUI.bat)  <- *.mm file

Here is an example of exporting a proof from Metamath's Proof Assistant
to a proof worksheet, which will be called a1i.mmp.  Before running
eimmexp.cmd, all steps must be unified; type "show new_proof /
not_unified" if uncertain - no steps should be displayed.  The
"/ silent" switch suppresses screen output, but you may want to omit
this to become familiar with what's happening and to identify and
document a bug.

  MM> prove a1i
  MM-PA> unify all / interactive
  MM-PA> submit eimmexp.cmd / silent

Here is an example of importing the proof worksheet a1i.mmp into
Metamath's Proof Assistant.  Note that the original proof will be
overwritten.

  MM> prove a1i
  MM-PA> submit eimmimp.cmd / silent
  MM-PA> submit tmp.cmd / silent

The examples above assume that the eimm program is in your directory
PATH (e.g., the local directory on Windows or if your path includes ".")
and that the .cmd files are in the local directory.

The exported/imported proofs do not have to be complete.  This way you
can start working on a proof in the Metamath program then switch over to
the mmj2 PA GUI to complete it, or vice-versa.
