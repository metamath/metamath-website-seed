#define VERSION "0.08 23-Mar-2021"
/*****************************************************************************/
/* eimm.c - Export/import between mmj2 proof worksheets and the Metamath     */
/*          program's Proof Assistant                                        */
/* Compile with "gcc eimm.c -o eimm".  Type "eimm --help" for instructions.  */
/*                                                                           */
/*                           PUBLIC DOMAIN                                   */
/*                                                                           */
/* This file (specifically, the version of this file with the above date)    */
/* has been released into the Public Domain per the Creative Commons Public  */
/* Domain Dedication. http://creativecommons.org/licenses/publicdomain/      */
/*                                                                           */
/* Norman Megill  nm(at)alum(dot)mit(dot)edu                                 */
/*****************************************************************************/

/* 0.06 23-Oct-2006 nm */
/* 0.07 18-Oct-2010 nm - increase MAX_PROOF_STEPS from 1000 to 10000 */
/* 0.08 23-Mar-2021 nm - change "dummylink" to "a1ii"; also fixed
   several gcc warnings */

#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <ctype.h>


/******* Start of "variable-length string handler" prototypes ****************/

/*****************************************************************************/
/* The "variable-length string handler" prototypes and functions have        */
/* been released into the Public Domain per the Creative Commons Public      */
/* Domain Dedication. http://creativecommons.org/licenses/publicdomain/      */
/* Norman Megill - email: nm(at)alum(dot)mit(dot)edu - 18-Apr-2006           */
/*****************************************************************************/

/* See the code section for instructions on how to use these functions. */

typedef char* vstring;

/* String assignment - MUST be used to assign vstrings */
void let(vstring *target,vstring source);
/* String concatenation - last argument MUST be NULL */
vstring cat(vstring string1,...);

/* Emulate BASIC linput statement; returns NULL if EOF */
/* Note that linput assigns target string with let(&target,...) */
  /*
    BASIC:  linput "what";a$
    c:      linput(NULL,"what?",&a);

    BASIC:  linput #1,a$                        (error trap on EOF)
    c:      if (!linput(file1,NULL,&a)) break;  (break on EOF)

  */
int linput(FILE *stream, const char* ask, vstring *target);

/* Emulation of BASIC string functions */
vstring seg(vstring sin, long p1, long p2);
vstring mid(vstring sin, long p, long l);
vstring left(vstring sin, long n);
vstring right(vstring sin, long n);
vstring edit(vstring sin, long control);
vstring space(long n);
vstring string(long n, char c);
vstring chr(long n);
vstring xlate(vstring sin, vstring control);
vstring date(void);
vstring time_(void);
vstring num(double x);
vstring num1(double x);
vstring str(double x);
long len(vstring s);
long instr(long start, vstring sin, vstring s);
long ascii_(vstring c);
double val(vstring s);
/* Emulation of PROGRESS string functions added 11/25/98 */
vstring entry(long element, vstring list);
long lookup(vstring expression, vstring list);
long numEntries(vstring list);
long entryPosition(long element, vstring list);
/* Print to log file as well as terminal if fplog opened */
void print2(char* fmt,...);
FILE *fplog = NULL;
/* Opens files with error message; opens output files with
   backup of previous version.   Mode must be "r" or "w". */
FILE *fSafeOpen(vstring fileName, vstring mode);


/******* Special pupose routines for better
      memory allocation (use with caution) *******/
/* Make string have temporary allocation to be released by next let() */
/* Warning:  after makeTempAlloc() is called, the vstring may NOT be
   assigned again with let() */
void makeTempAlloc(vstring s);   /* Make string have temporary allocation to be
                                    released by next let() */
/* Remaining prototypes (outside of mmvstr.h) */
char *tempAlloc(long size);     /* String memory allocation/deallocation */

#define MAX_ALLOC_STACK 100
int tempAllocStackTop=0;        /* Top of stack for tempAlloc functon */
int startTempAllocStack=0;      /* Where to start freeing temporary allocation
                                    when let() is called (normally 0, except in
                                    special nested vstring functions) */
char *tempAllocStack[MAX_ALLOC_STACK];

/* Bug check error */
void bug(int bugNum);

/********* End of "variable-length string handler" prototypes ****************/

/******************** Prototypes *********************************************/
char export(void);
char import(void);

void printImportStep(
        FILE* fpout,
        vstring label,
        vstring *stepLabel,
        vstring *hypLabelList,
        vstring *sourceLabel,
        char *statementType,
        vstring *proofLineWff,
        long *unknownStepsAddr,
        long proofSteps);

void printExportError(void);
void printHelp(void);
void init(void);

/******************** Global variables ***************************************/
char expImpCmd = 0; /* 1 = export to worksheet, 2 = import from worksheet */
long userArg; /* (not currently used) */
FILE *inputFp = NULL;  /* Input file (not currently used) */

#define MAX_PROOF_STEPS 10000

/******************** Main program *******************************************/

int main(int argc, char *argv[])
{

  long argOffset;
  char argOffsetChanged;

  /* argc is the number of arguments; argv points to array containing them */


  /* No arguments means print help */
  /*
  if (argc <= 1) {
    printHelp();
    return 0;
  }
  */

  /* Get command line options */
  expImpCmd = 0;
  userArg = 0;
  argOffset = 0;
  argOffsetChanged = 1;

  while (argOffsetChanged) {
    argOffsetChanged = 0;
    if (argc - argOffset > 1 && !strcmp(argv[1 + argOffset], "--help")) {
      printHelp();
      return 0;
    }
    if (argc - argOffset > 1 && !strcmp(argv[1 + argOffset], "-e")) {
      argOffset++;
      argOffsetChanged = 1;
      expImpCmd = 1;
    }
    if (argc - argOffset > 1 && !strcmp(argv[1 + argOffset], "-i")) {
      argOffset++;
      argOffsetChanged = 1;
      expImpCmd = 2;
    }

 /* Skip some sample code that may or may not be useful in the future */
 if (argc == argc + 0) goto SKIPXXX;
    if (argc - argOffset > 1 && !strcmp(argv[1 + argOffset], "-ixxx")) {
      if (argc - argOffset > 2) {
        /* Open the output file */
        inputFp = fopen(argv[2 + argOffset], "r");
        if (inputFp == NULL) {
          print2("?Error: Couldn't open the file \"%s\".\n",
              argv[2 + argOffset]);
          return 0;
        }
      } else {
        print2("?Error: No input file specified.\n");
        return 0;
      }
      argOffset += 2;
      argOffsetChanged = 1;
    }
    if (argc - argOffset > 1 && !strcmp(argv[1 + argOffset], "-o")) {
      if (argc - argOffset > 2) {
        if (fplog != NULL) {
          print2("?Error: Cannot specify more than one output file.\n");
          return 0;
        }
        /* Open the output file */
        fplog = fSafeOpen(argv[2 + argOffset], "w");
        if (fplog == NULL) {
          return 0;
        }
        /* Disable buffering of the output file so that all partial results
           will be there in case a run is aborted before completion */
        setbuf(fplog, NULL);
      } else {
        print2("?Error: No output log file specified.\n");
        return 0;
      }
      argOffset += 2;
      argOffsetChanged = 1;
    }
    if (argc - argOffset > 1 && !strcmp(argv[1 + argOffset], "-n")) {
      if (argc - argOffset > 2) userArg = (long)val(argv[2 + argOffset]);
      if (userArg <= 0  || strcmp(argv[2 + argOffset], str((double)userArg))) {
        print2("?Error: Expected positive integer after -n\n");
        return 0;
      }
      argOffset += 2;
      argOffsetChanged = 1;
    }
 SKIPXXX: argOffset++; argOffset--; /* Work around bug on very old compilers */

  }

  init(); /* One-time initialization */

  if (expImpCmd == 0 || argc != 2) {
    printf(
        "?Error:  You must specify -e (export) or -i (import), or --help.\n");
    return 1;
  }

  if (expImpCmd == 1) {
    if (export()) return 1;
  } else {
    if (import()) return 1;
  }

  /*print2("Hello world\n");*/
  return 0; /* Success */
} /* main */



/* Export function: metamath -> mmj2 */
/* Returns 0 if success, 1 if error found */
char export(void)
{
  vstring str1 = "";
  vstring str2 = "";
  vstring matchPrefixes = "";
  vstring matchLineNums = "";
  vstring hypList = "";
  vstring hypStepList = "";
  long hypotheses = 0;
  long i, j;
  long line;
  char returnVal = 1;
  long stepNumEndPos;
  long indentStartPos;
  long step;
  FILE *fpout = NULL;
  vstring fout = "";
  long maxPrefixLen;
  char passNum;

  vstring proofLine[MAX_PROOF_STEPS];
  long stepNum[MAX_PROOF_STEPS];
  long indentation[MAX_PROOF_STEPS];
  vstring targetLabel[MAX_PROOF_STEPS];
  vstring sourceLabel[MAX_PROOF_STEPS];
  char statementType[MAX_PROOF_STEPS];
  vstring proofLineWff[MAX_PROOF_STEPS];
  long inputLines = 0;
  long proofSteps = 0;

  /* Initialize proof storage array */
  for (i = 0; i < MAX_PROOF_STEPS; i++) {
    proofLine[i] = "";
  }

  while (1) {
    if (inputLines >= MAX_PROOF_STEPS) {
      printf("?Error: The input file must have less than %ld lines\n",
          (long)MAX_PROOF_STEPS);
      goto RETURN_EXP_ERROR;
    }

    /* Get line from input file */
    if (linput(NULL, NULL, &str1) == 0) break; /* 0 means EOF */
    /* Clean off carriage return (for Windows files under Cygwin) */
    let(&str1, edit(str1, 4));
    /* Populate the proof storage array */
    proofLine[inputLines] = "";
    let(&(proofLine[inputLines]), str1);
    inputLines++;
  }

#define EXTRA_INPUT_LINES 6  /* Garbage before and after proof */
#define PROOF_START_LINE 5  /* Line proof starts on */
  /* Check for basic errors */
  let(&matchPrefixes, cat(
      "The log file" , ",",
      "MM-PA> se" , ",",
      "Screen width" , ",",
      "MM-PA> sh" , ",",
      "MM-PA> c" , ",",
      "The log file" , NULL));
  let(&matchLineNums, cat("1,2,3,4,",
      str((double)(inputLines - 1)), ",", str((double)inputLines), NULL));
  for (i = 1; i <= numEntries(matchLineNums); i++) {
    j = (long)val(entry(i, matchLineNums));
    let(&str1, entry(i, matchPrefixes));
    if (strcmp(left(proofLine[j - 1], (long)strlen(str1)), str1)) {
      printf(
  "?Error: Line %ld of the input file must start with \"%s\".\n",
         j, str1);
      printf(" Instead, the line erroneously reads:\n   %s\n",
          proofLine[j - 1]);
      goto RETURN_EXP_ERROR;
    }
  }


  if (instr(1, proofLine[1], "999") == 0) {
    printf(
"?Error: The 2nd line of the input file must contain \"999\".\n"
        );
    goto RETURN_EXP_ERROR;
  }
  for (line = PROOF_START_LINE - 1;
      line <= inputLines - EXTRA_INPUT_LINES + PROOF_START_LINE - 2; line++) {
    if (!strcmp(left(proofLine[line], (long)strlen("MM-PA")),
        "MM-PA")) {
      printf(
"?Error: \"MM-PA\" occurs in the middle of the proof, on line %ld.\n",
          (long)(line + 1));
      goto RETURN_EXP_ERROR;
    }
    let(&str1, ""); /* Clear temporary string allocation in 'left' above */
  }

  /* Populate the working arrays */
  /*
  vstring proofLine[MAX_PROOF_STEPS];
  long stepNum[MAX_PROOF_STEPS];
  long indentation[MAX_PROOF_STEPS];
  vstring targetLabel[MAX_PROOF_STEPS];
  vstring sourceLabel[MAX_PROOF_STEPS];
  char statementType[MAX_PROOF_STEPS];
  vstring proofLineWff[MAX_PROOF_STEPS];
  */
  /* The populated arrays will reference the proof step line number, not
     the input line number */
  proofSteps = inputLines - EXTRA_INPUT_LINES;
  i = 1;
  /* Get last proof step */
  let(&str1, proofLine[inputLines - EXTRA_INPUT_LINES + PROOF_START_LINE - 2]);
  while (1) {   /* Get to 1st non-blank */
    if (str1[i - 1] == 0) bug(10);
    if (str1[i - 1] != ' ') break;
    i++;
  }
  while (1) {  /* Get to 1st blank after that */
    if (str1[i - 1] == 0) bug(11);
    if (str1[i - 1] == ' ') break;
    i++;
  }
  stepNumEndPos = i - 1;  /* End of the right-justified step number */
  while (1) {   /* Get to 1st non-blank */
    if (str1[i - 1] == 0) bug(12);
    if (str1[i - 1] != ' ') break;
    i++;
  }
  indentStartPos = i; /* Outermost indentation */

  step = 0;
  for (line = PROOF_START_LINE - 1;
      line <= inputLines - EXTRA_INPUT_LINES + PROOF_START_LINE - 2; line++) {
    let(&str1, proofLine[line]);
    stepNum[step] = (long)val(left(str1, stepNumEndPos));
    i = indentStartPos;
    while (1) {  /* Get to 1st non-blank */
      if (str1[i - 1] == 0) bug(13);
      if (str1[i - 1] != ' ') break;
      i++;
    }
    indentation[step] = (i - indentStartPos) / 2;
    if (indentation[step] * 2 != (i - indentStartPos)) bug(14);
    /* i now points to target label in proof step. */
    j = i;
    while (1) {
      if (str1[j - 1] == 0) bug(15);
      if (str1[j - 1] == '=') break;
      j++;
    }
    /* j now points to = sign. */
    targetLabel[step] = "";
    let(&(targetLabel[step]), seg(str1, i, j - 1));
    i = j + 1;
    j = i;
    /* i now points to just after = sign. */
    while (1) {
      if (str1[j - 1] == 0) bug(16);
      if (str1[j - 1] == ' ') break;
      j++;
    }
    /* j now points to space after source label. */
    sourceLabel[step] = "";
    let(&(sourceLabel[step]), seg(str1, i, j - 1));
    i = j;
    while (1) {
      if (str1[j - 1] == 0) bug(17);
      if (str1[j - 1] != ' ') break;
      j++;
    }
    /* j now points to $ */
    if (str1[j - 1] != '$') bug(18);
    statementType[step] = str1[j];
    proofLineWff[step] = "";
    let(&(proofLineWff[step]), right(str1, j + 3));
    step++;
  }
  if (step != proofSteps) bug(19);

  /* Collect the hypotheses */
  hypotheses = 0;
  let(&hypList, "");
  let(&hypStepList, "");
  for (step = 0; step < proofSteps; step++) {
    if (statementType[step] != 'e') continue;
    i = lookup(sourceLabel[step], hypList);
    if (i == 0) {
      let(&str2, hypotheses ? "," : "");
      hypotheses++;
      let(&hypList, cat(hypList,
          str2, sourceLabel[step], NULL));
      let(&hypStepList, cat(hypStepList, str2, str((double)step), NULL));
    }
  }

  /* Now produce the output file */
  let(&fout, cat(targetLabel[proofSteps - 1], ".mmp", NULL));
  print2("The output file is called \"%s\".\n", fout);

  /* Open the output file */
  fpout = fSafeOpen(fout, "w");
  if (fpout == NULL) {
    printf("?Error: could not open output file \"%s\".\n",
        fout);
    return 0;
  }


  fprintf(fpout, "$( <MM> <PROOF_ASST> THEOREM=%s  LOC_AFTER=?\n",
      targetLabel[proofSteps - 1]);
  fprintf(fpout, "\n");
  /* Output the hypotheses */
  maxPrefixLen = 0;
  for (passNum = 1; passNum <= 2; passNum++) {
    /* Pass 1: compute the largest "::" length maxPrefixLen */
    /* Pass 2: produce the output */
    for (i = 1; i <= numEntries(hypList); i++) {
      let(&str1, cat("h", str((double)stepNum[(long)((long)val(entry(i, hypStepList)))]),
          "::", entry(i, hypList), NULL));
      if (passNum == 1) {
        if (maxPrefixLen < (long)strlen(str1))
          maxPrefixLen = (long)strlen(str1);
      } else {
        /* String of blanks to indent the output wffs */
        let(&str2, space(1 + maxPrefixLen - (long)strlen(str1)));
        /* Print the final step */
        fprintf(fpout, "%s%s%s\n", str1, str2,
            proofLineWff[(long)((long)val(entry(i, hypStepList)))]);
      }
    }
  }
  /* Output the steps */
  maxPrefixLen = 0;
  for (passNum = 1; passNum <= 2; passNum++) {
    /* Pass 1: compute the largest "::" length maxPrefixLen */
    /* Pass 2: produce the output */
    for (step = 0; step < proofSteps; step++) {
      /* If the source is a hypothesis, skip it */
      if (statementType[step] == 'e') continue;
      i = indentation[step];
      let(&str1, "");
      /* Scan back below current indentation level to find hypotheses */
      for (j = step - 1; j >= 0; j--) {
        if (indentation[j] <= i) break;
        if (indentation[j] == i + 1) {
          if (statementType[j] == 'e') {
            /* Add a $e hypothesis */
            let(&str1, cat(str(
                  (double)stepNum[(long)val(entry(lookup(
                  sourceLabel[j], hypList), hypStepList))]),
                (long)strlen(str1) ? "," : "",  str1, NULL));
          } else {
            /* Add some earlier step as the hypothesis */
            let(&str1, cat(str((double)stepNum[j]),
                (long)strlen(str1) ? "," : "", str1, NULL));
          }
        }
      }
      /* Build the :: part */
      let(&str1, cat(
          (step == proofSteps - 1) ? "qed" : str((double)stepNum[step]),
          ":", str1, ":",
          !strcmp("?", sourceLabel[step]) ? "" : sourceLabel[step],
          NULL));
      if (passNum == 1) {
        /* The (2 * i) conserves screen space */
        if (maxPrefixLen < ((long)strlen(str1)) - (2 * i)) {
          maxPrefixLen = ((long)strlen(str1)) - (2 * i);
        }
      } else {
        /* String of blanks to indent the output wffs */
        let(&str2, space((2 * i) + 1 + maxPrefixLen - (long)strlen(str1)));
        /* Print the final step */
        fprintf(fpout, "%s%s%s\n", str1, str2, proofLineWff[step]);
      }
    } /* next step */
  } /* next passNum */

  fprintf(fpout, "\n");
  fprintf(fpout, "$)\n");

  fclose(fpout);


  returnVal = 0; /* Success */
 RETURN_EXP_ERROR:
  if (returnVal) printExportError();
  /* -- Do this if this function is called more than once! -- */
  /* -- Remember to deallocate string array entries also! -- */

  return (returnVal);

} /* export */



/* Import function: mmj2 -> metamath */
/* Returns 0 if success, 1 if error found */
char import(void)
{
  vstring str1 = "";
  vstring str2 = "";
  vstring matchPrefixes = "";
  vstring matchLineNums = "";
  long i, j;
  long firstProofLine, lastProofLine;
  vstring statementBeingProved = "";
  long line;
  char returnVal = 1;
  long step;
  FILE *fpout = NULL;
  vstring fout = "";
  long inputLines = 0;
  long proofSteps;
  char found;
  long unknownSteps;
  long rawInputLines;

  vstring proofLine[MAX_PROOF_STEPS];
  long rawInputLineNum[MAX_PROOF_STEPS]; /* For error messages */

  vstring stepLabel[MAX_PROOF_STEPS];
  vstring hypLabelList[MAX_PROOF_STEPS];
  vstring sourceLabel[MAX_PROOF_STEPS];
  char statementType[MAX_PROOF_STEPS];
  vstring proofLineWff[MAX_PROOF_STEPS];

  inputLines = -1;
  rawInputLines = 0;


  /* Initialize proof storage array */
  for (i = 0; i < MAX_PROOF_STEPS; i++) {
    proofLine[i] = "";
  }

  while (1) {
    if (inputLines >= MAX_PROOF_STEPS) {
      printf("?Error: The input file must have less than %ld lines\n",
          (long)MAX_PROOF_STEPS);
      goto RETURN_IMP_ERROR;
    }

    /* Get line from input file */
    if (linput(NULL, NULL, &str1) == 0) break; /* 0 means EOF */
    rawInputLines++;

    /* Clean off carriage return (for Windows files under Cygwin) */
    let(&str1, edit(str1, 4));
    /* Reduce whitespace; remove trailing blanks */
    let(&str1, edit(str1, 16 + 128));
    /* Populate the proof storage array */
    if (isgraph((long)str1[0])) {
      inputLines++;
      proofLine[inputLines] = "";
      let(&(proofLine[inputLines]), str1);
      rawInputLineNum[inputLines] = rawInputLines; /* For error msgs */
    } else {
      /* It starts with space, so assume continuation line */
      if (inputLines == -1) {
        printf(
             "?Error: input file must start with \"$( <MM> <PROOF_ASST>\"\n");
        goto RETURN_IMP_ERROR;
      }
      let(&(proofLine[inputLines]), cat(proofLine[inputLines], str1, NULL));
    }
  }
  inputLines++;

  /* Check for basic errors */
  let(&matchPrefixes, cat(
      "$( <MM> <PROOF_ASST> THEOREM=", ",",
      "$)", NULL));
  let(&matchLineNums, cat("1,", str((double)inputLines), NULL));
  for (i = 1; i <= numEntries(matchLineNums); i++) {
    j = (long)val(entry(i, matchLineNums));
    let(&str1, entry(i, matchPrefixes));
    if (strcmp(left(proofLine[j - 1], (long)strlen(str1)), str1)) {
      printf(
  "?Error: Line %ld of the input file must start with \"%s\".\n",
         rawInputLineNum[j - 1], str1);
      printf(" Instead, the line erroneously reads:\n   %s\n",
          proofLine[j - 1]);
      goto RETURN_IMP_ERROR;
    }
  }

  firstProofLine = 2;
  if (!strcmp("qed", left(proofLine[inputLines - 2], 3))) {
    lastProofLine = inputLines - 1;
  } else if (!strcmp("qed", left(proofLine[inputLines - 3], 3))) {
    lastProofLine = inputLines - 2;
  } else {
    printf(
"?Error: The penultimate or antepenultimate line did not begin \"qed\"\n");
    goto RETURN_IMP_ERROR;
  }

  /* Get the name of the theorem we're proving */
  let(&str1, "$( <MM> <PROOF_ASST> THEOREM=");
  i = instr((long)strlen(str1), proofLine[0], " ");
  if (i == 0) {
    printf("?Error: Space after THEOREM name in first line is missing\n");
    goto RETURN_IMP_ERROR;
  }
  let(&statementBeingProved, seg(proofLine[0], (long)strlen(str1) + 1, i - 1));


  /* Populate the working arrays */
  /*
  vstring proofLine[MAX_PROOF_STEPS];
  vstring stepLabel[MAX_PROOF_STEPS];
  vstring hypLabelList[MAX_PROOF_STEPS];
  vstring sourceLabel[MAX_PROOF_STEPS];
  char statementType[MAX_PROOF_STEPS];
  vstring proofLineWff[MAX_PROOF_STEPS];
  */
  /* The populated arrays will reference the proof step line number
     (0-based), not the input line number */
  for (line = firstProofLine; line <= lastProofLine; line++) {
    /* Note that 'line' is 1-based */
    step = line - firstProofLine + 1;   /* Note that 'step' is 1-based */
    let(&str1, proofLine[line - 1]);

    i = instr(1, str1, ":");
    if (i == 0) {
      printf("?Error: No colon in line %ld of input file.",
          rawInputLineNum[line - 1]);
      goto RETURN_IMP_ERROR;
    }
    stepLabel[step - 1] = ""; /* Always init string before 1st let()! */
    let(&(stepLabel[step - 1]), left(str1, i - 1));

    j = i;
    i = instr(j + 1, str1, ":");
    if (i == 0) {
      printf("?Error: No second colon in line %ld of input file.",
          rawInputLineNum[line - 1]);
      goto RETURN_IMP_ERROR;
    }
    hypLabelList[step - 1] = "";
    let(&(hypLabelList[step - 1]), seg(str1, j + 1, i - 1));

    j = i;
    i = instr(j + 1, str1, " ");
    if (i == 0) i = (long)strlen(str1) + 1; /* In case math string unknown */
    sourceLabel[step - 1] = "";
    let(&(sourceLabel[step - 1]), seg(str1, j + 1, i - 1));

    j = i;
    proofLineWff[step - 1] = "";
    let(&(proofLineWff[step - 1]), right(str1, j + 1));

    /* If hypothesis is ?, there should be no source.  (If there is,
       a future version could look up the hypotheses in the .mm file,
       but it can't be done with just the info in the .mmp file.)
       So, if the hypothesis is ?, then clear both source and hypotheses
       to make them "unknown." */
    if (!strcmp(hypLabelList[step - 1], "?")) {
      let(&(hypLabelList[step - 1]), "");
      if (!(sourceLabel[step - 1])[0]) {
        let(&(sourceLabel[step - 1]), "");
      }
    }

    /* If source is unknown, there should be no hypotheses */
    if (!(sourceLabel[step - 1])[0]) {
      if ((hypLabelList[step - 1])[0]) {
        printf(
"?Error: Unknown step in line %ld has hypotheses \"%s\" (should have none).\n",
            rawInputLineNum[line - 1], hypLabelList[step - 1]);
        goto RETURN_IMP_ERROR;
      }
    }

  }
  proofSteps = lastProofLine - firstProofLine + 1;

  /* Determine statement types */
  for (step = 1; step <= proofSteps; step++) {
    if (!strcmp(stepLabel[step - 1], "qed")) {
      statementType[step - 1] = 'q'; /* Conclusion */
    } else if ((stepLabel[step - 1])[0] == 'h') {
      statementType[step - 1] = 'h'; /* Hypothesis of statement being proved */
      /* Extract statement number nn from hnn */
      let(&str2, right(stepLabel[step - 1], 2));
      if (strcmp(str2, str((double)val(str2)))) {
        printf(
          "?Error: Step label \"%s\" is not in the form \"h\"+nn on line %ld.",
            str2, rawInputLineNum[step + firstProofLine - 1 - 1]);
        goto RETURN_IMP_ERROR;
      }
      if ((hypLabelList[step - 1])[0]) {
        printf(
            "?Error: Line %ld is a hypothesis but references hypotheses %s\n",
            rawInputLineNum[step + firstProofLine - 1 - 1],
            hypLabelList[step - 1]);
        goto RETURN_IMP_ERROR;
      }
      let(&(stepLabel[step - 1]), str2);
    } else {
      statementType[step - 1] = 'a';  /* Assertion, $p or $a */
      /* Anything else must be a number */
      let(&str2, stepLabel[step - 1]);
      if (strcmp(str2, str((double)val(str2)))) {
        printf(
           "?Error: Step label \"%s\" is not a number on line %ld.",
            str2, rawInputLineNum[step + firstProofLine - 1 - 1]);
        goto RETURN_IMP_ERROR;
      }
    }

    /* Check that all hypotheses refer to labels */
    for (i = 1; i <= numEntries(hypLabelList[step - 1]); i++) {
      let(&str1, entry(i, hypLabelList[step - 1]));
      found = 0;
      for (j = 1; j <= proofSteps; j++) {
        if (!strcmp(str1, stepLabel[j - 1])) {
          found = 1;
          break;
        }
      }
      if (!found) {
        printf("?Error: Hypothesis \"%s\" in line %ld is not a label.\n",
            str1, rawInputLineNum[step + firstProofLine - 1 - 1]);
        goto RETURN_IMP_ERROR;
      }
    }

  } /* next step */


  /* Now produce the output file */
  let(&fout, "tmp.cmd");
  print2("The output file is called \"%s\".\n", fout);

  /* Open the output file */
  fpout = fSafeOpen(fout, "w");
  if (fpout == NULL) {
    printf("?Error: could not open output file \"%s\".\n",
        fout);
    goto RETURN_IMP_ERROR;
  }


  fprintf(fpout, "! Proof assigment for %s\n", statementBeingProved);
  fprintf(fpout, "SAVE NEW_PROOF /COMPRESSED\n");
  fprintf(fpout, "DELETE ALL\n");

  unknownSteps = 0;
  /* Generate orphan proofs with a1ii (was dummylink) */
  for (step = 1; step <= proofSteps - 1; step++) { /* Scan to before "qed" */
    /* See if the step's label is referenced in some hypothesis */
    let(&str1, stepLabel[step - 1]);
    found = 0;
    for (i = 1; i <= proofSteps; i++) {
      for (j = 1; j <= numEntries(hypLabelList[i - 1]); j++) {
        let(&str2, entry(j, hypLabelList[i - 1]));
        if (!strcmp(str1, str2)) {
          found = 1;
          break;
        }
      }
      if (found) break;
    }
    if (!found) {  /* It's an orphan subproof conclusion step */
      if (!unknownSteps) {
        fprintf(fpout, "ASSIGN LAST a1ii / NO_UNIFY\n");
      } else {
        /* Use the new minus offset feature of Metamath >= 0.07.16 */
        fprintf(fpout, "ASSIGN %ld a1ii / NO_UNIFY\n", - unknownSteps);
      }
      /* Recursively generate orphan proof assignment */
      printImportStep(
          fpout,
          str1,
          stepLabel,
          hypLabelList,
          sourceLabel,
          statementType,
          proofLineWff,
          &unknownSteps,
          proofSteps);
    } /* if orphan step */
  } /* next step */

  /* Recursively generate proof assignment */
  printImportStep(
      fpout,
      "qed",
      stepLabel,
      hypLabelList,
      sourceLabel,
      statementType,
      proofLineWff,
      &unknownSteps,
      proofSteps);

  /* Final unification, etc. */
  fprintf(fpout, "UNIFY ALL\n");
  fprintf(fpout, "IMPROVE ALL\n");
  fprintf(fpout, "INITIALIZE USER\n");

  fclose(fpout);


  returnVal = 0; /* Success */
 RETURN_IMP_ERROR:
  /* Deallocate strings */
  /* -- Do this if this function is called more than once! -- */
  /* -- Remember to deallocate string array entries also! -- */
  return (returnVal);


} /* import */


/* Recursive function to print "assign"s */
void printImportStep(
        FILE* fpout,
        vstring label,
        vstring *stepLabel,
        vstring *hypLabelList,
        vstring *sourceLabel,
        char *statementType,
        vstring *proofLineWff,
        long *unknownStepsAddr,
        long proofSteps)
{

  long step, i;
  char found;
  vstring str1 = "";

  /* Find the label */
  found = 0;
  for (step = 1; step <= proofSteps; step++) {
    if (!strcmp(label, stepLabel[step - 1])) {
      found = 1;
      break;
    }
  }
  if (!found) {
    bug(30); /* This is error-checked in advance */
  }

  /* If the step has a known math string, assign it.  This is optional,
     but it will make unifications less ambiguous. */
  let(&str1, proofLineWff[step - 1]);
  if (str1[0]) {
    if (instr(1, str1, "\"")) { /* Decide on kind of quotes to use */
      if (!instr(1, str1, "'")) { /* Don't assign if both ' and " in wff */
        /* Use the new minus offset feature of Metamath >= 0.07.16 */
        fprintf(fpout, "LET STEP %ld = '%s'\n", - *unknownStepsAddr, str1);
      }
    } else {
      /* Use the new minus offset feature of Metamath >= 0.07.16 */
      fprintf(fpout, "LET STEP %ld = \"%s\"\n", - *unknownStepsAddr, str1);
    }
  }

  /* If the step label is known, assign it */
  let(&str1, sourceLabel[step - 1]);
  if (str1[0]) {
    if (!(*unknownStepsAddr)) {
      fprintf(fpout, "ASSIGN LAST %s / NO_UNIFY\n", str1);
    } else {
      /* Use the new minus offset feature of Metamath >= 0.07.16 */
      fprintf(fpout, "ASSIGN %ld %s / NO_UNIFY\n", - *unknownStepsAddr, str1);
    }
  } else {
    /* Increment the unknown step count to be skipped in assign's */
    *unknownStepsAddr = (*unknownStepsAddr) + 1;
  }

  /* Scan hypotheses */
  for (i = numEntries(hypLabelList[step - 1]); i >= 1; i--) {
    let(&str1, entry(i, hypLabelList[step - 1]));
    printImportStep(
        fpout,
        str1,
        stepLabel,
        hypLabelList,
        sourceLabel,
        statementType,
        proofLineWff,
        &(*unknownStepsAddr),
        proofSteps);
  } /* next i */

  let(&str1, "");
  return;

} /* printImportStep */



void printExportError(void) {
  print2(" See \"eimm --help\" for how to create the input file.\n");
  /*
  print2(
" (You must generate the input file inside of the Metamath Proof\n");
  print2(
" Assistant, using 'open log <filename>', 'set width 999',\n");
  print2(
" 'show new_proof', 'close log'.)\n");
  */
  return;
}



void printHelp(void)
{
print2("eimm.c - Export/import between mmj2 worksheets and Metamath's MMPA\n");
print2("Version %s\n", VERSION);
print2("\n");
print2("Note:  normally you will not run eimm directly but will use one\n");
print2("of the two commands at the Metamath MM-PA> prompt:\n");
print2("      submit eimmexp.cmd /s   to export\n");
print2("      submit eimmimp.cmd /s   to import\n");
print2("See the readme.txt file in this directory for details.\n");
print2("\n");
print2("The following instructions describe how to run eimm directly.\n");
print2("\n");
print2("Usage: eimm [options] < inputfile\n");
print2("Options:\n");
print2("  -e - export to mmj2 worksheet\n");
print2("  -i - import from mmj2 worksheet\n");
print2("For -e, the output file is called <theorem>.mmp where <theorem> is\n");
print2("obtained from the input file (see below).  For -i, the output\n");
print2("filename is hardcoded to be tmp.cmd.  In both cases. any previous\n");
print2("version of the output file is renamed with a ~1 suffix.\n");
print2(
"\n");
print2(
"The export function reads in a log file from the Metamath Proof\n");
print2(
"Assistant and converts it to a proof worksheet.  The following command\n");
print2(
"sequence creates the log file and runs the export function, which\n");
print2(
"will create a proof worksheet called a1i.mmp.\n");
print2(
"  MM> prove a1i\n");
print2(
"  MM-PA> unify all / interactive\n");
print2(
"  MM-PA> open log tmp.log\n");
print2(
"  MM-PA> set width 999\n");
print2(
"  MM-PA> show new_proof / renumber\n");
print2(
"  MM-PA> close log\n");
print2(
"  MM-PA> 'eimm -e < tmp.log'\n");
print2(
"\n");
print2(
"The import function inputs a .mmp proof worksheet and generates commands\n");
print2(
"to build the proof in the Metamath program's Proof Assistant.  Note that\n");
print2(
"tmp.cmd overwrites (i.e. deletes) the existing proof.  Example of its use:\n");
print2(
"  MM> prove a1i\n");
print2(
"  MM-PA> 'eimm -i < a1i.mmp'\n");
print2(
"  MM-PA> submit tmp.cmd\n");
print2(
"\n");
print2(
"The export function has the following limitations.\n");
print2(
"1. The proof must have less than %ld lines.\n", (long)MAX_PROOF_STEPS);
print2(
"   (A future version may allocate space dynamically.)\n");
print2(
"2. The longest line in a proof must have 9999 characters or less.\n");
print2(
"   (A future version may recognize wrapped lines.)\n");
print2(
"\n");
print2(
"The import function has the following limitations.\n");
print2(
"1. The proof must have less than %ld lines.\n", (long)MAX_PROOF_STEPS);
print2(
"   (A future version may allocate space dynamically.)\n");
/*linput(NULL,"Press Enter to continue, q to quit...",&a);*/
/*if (toupper(a[0]) == 'Q') goto returnPoint;*/
/*returnPoint:*/
/*let(&a, "");*/ /* Deallocate string */
return;
} /* printHelp() */


void init(void) /* Should be called only once!! */
{
  return;
} /* init */


/* Start of "variable-length string handler" functions */

/*****************************************************************************/
/* The "variable-length string handler" prototypes and functions are         */
/* released into the Public Domain per the Creative Commons Public           */
/* Domain Dedication. http://creativecommons.org/licenses/publicdomain/      */
/* Norman Megill - email: nm(at)alum(dot)mit(dot)edu - 18-Apr-2006           */
/*****************************************************************************/

/******************************************************************************

Variable-length string handler
------------------------------

     This collection of string-handling functions emulate most of the
string functions of VMS BASIC.  The objects manipulated by these
functions are strings of a special type called 'vstring' which have no
pre-defined upper length limit but are dynamically allocated and
deallocated as needed.  To use the vstring functions within a program,
all vstrings must be initially set to the null string when declared or
before first used, for example:

        vstring string1 = "";
        vstring stringArray[] = {"", "", ""};

        vstring bigArray[100][10]; /- Must be initialized before using -/
        int i, j;
        for (i = 0; i < 100; i++)
          for (j = 0; j < 10; j++)
            bigArray[i][j] = ""; /- Initialize -/


     After initialization, vstrings should be assigned with the 'let(&'
function only; for example the statements

        let(&string1, "abc");
        let(&string1, string2);
        let(&string1, left(string2, 3));

all assign the second argument to 'string1'.  The 'let(&' function must
_not_ be used to initialize a vstring the first time.

     Any local vstrings in a function must be deallocated before returning
from the function, otherwise there will be memory leakage and eventual
memory overflow.  To deallocate, assign the vstring to "" with 'let(&':

        void abc(void) {
          vstring xyz = "";
          ...
          let(&xyz, "");
        }

     The 'cat' function emulates the '+' concatenation operator in BASIC.
It has a variable number of arguments, and the last argument should always
be NULL.  For example,

        let(&string1,cat("abc","def",NULL));

assigns "abcdef" to 'string1'.  Warning: 0 will work instead of NULL on the
VAX but not on the Macintosh, so always use NULL.

     All other functions are generally used exactly like their BASIC
equivalents.  For example, the BASIC statement

        let string1$=left$("def",len(right$("xxx",2)))+"ghi"+string2$

is emulated in c as

        let(&string1,cat(left("def",len(right("xxx",2))),"ghi",string2,NULL));

Note that ANSII c does not allow "$" as part of an identifier
name, so the names in c have had the "$" suffix removed.

     The string arguments of the vstring functions may be either standard c
strings or vstrings (except that the first argument of the 'let(&' function
must be a vstring).  The standard c string functions may use vstrings or
vstring functions as their string arguments, as long as the vstring variable
itself (which is a char * pointer) is not modified and no attempt is made to
increase the length of a vstring.  Caution must be excercised when
assigning standard c string pointers to vstrings or the results of
vstring functions, as the memory space may be deallocated when the
'let(&' function is next executed.  For example,

        char *stdstr; /- A standard c string pointer -/
         ...
        stdstr=left("abc",2);

will assign "ab" to 'stdstr', but this assignment will be lost when the
next 'let(&' function is executed.  To be safe, use 'strcpy':

        char stdstr1[80]; /- A fixed length standard c string -/
         ...
        strcpy(stdstr1,left("abc",2));

Here, of course, the user must ensure that the string copied to 'stdstr1'
does not exceed 79 characters in length.

     The vstring functions allocate temporary memory whenever they are called.
This temporary memory is deallocated whenever a 'let(&' assignment is
made.  The user should be aware of this when using vstring functions
outside of 'let(&' assignments; for example

        for (i=0; i<10000; i++)
          print2("%s\n",left(string1,70));

will allocate another 70 bytes or so of memory each pass through the loop.
If necessary, dummy 'let(&' assignments can be made periodically to clear
this temporary memory:

        for (i=0; i<10000; i++)
          {
          print2("%s\n",left(string1,70));
          let(&dummy,"");
          }

It should be noted that the 'linput' function assigns its target string
with 'let(&' and thus has the same effect as 'let(&'.

******************************************************************************/


vstring tempAlloc(long size)    /* String memory allocation/deallocation */
{
  /* When "size" is >0, "size" bytes are allocated. */
  /* When "size" is 0, all memory previously allocated with this */
  /* function is deallocated. */
  /* EXCEPT:  When startTempAllocStack != 0, the freeing will start at
     startTempAllocStack. */
  int i;
  if (size) {
    if (tempAllocStackTop>=(MAX_ALLOC_STACK-1)) {
      print2("?Error: Temporary string stack overflow\n");
      bug(101);
    }
    if (!(tempAllocStack[tempAllocStackTop++]=malloc((size_t)size))) {
      print2("?Error: Temporary string allocation failed\n");
      bug(102);
    }
    return (tempAllocStack[tempAllocStackTop-1]);
  } else {
    for (i=startTempAllocStack; i<tempAllocStackTop; i++) {
      free(tempAllocStack[i]);
    }
    tempAllocStackTop=startTempAllocStack;
    return (NULL);
  }
}


/* Make string have temporary allocation to be released by next let() */
/* Warning:  after makeTempAlloc() is called, the genString may NOT be
   assigned again with let() */
void makeTempAlloc(vstring s)
{
    if (tempAllocStackTop>=(MAX_ALLOC_STACK-1)) {
      print2("?Error: Temporary string stack overflow\n");
      bug(103);
    }
    tempAllocStack[tempAllocStackTop++]=s;
}


void let(vstring *target,vstring source)        /* String assignment */
/* This function must ALWAYS be called to make assignment to */
/* a vstring in order for the memory cleanup routines, etc. */
/* to work properly.  If a vstring has never been assigned before, */
/* it is the user's responsibility to initialize it to "" (the */
/* null string). */
{
  long targetLength,sourceLength;

  sourceLength=(long)strlen(source);  /* Save its length */
  targetLength=(long)strlen(*target); /* Save its length */
  if (targetLength) {
    if (sourceLength) { /* source and target are both nonzero length */

      if (targetLength>=sourceLength) { /* Old string has room for new one */
        strcpy(*target,source); /* Re-use the old space to save CPU time */
      } else {
        /* Free old string space and allocate new space */
        free(*target);  /* Free old space */
        *target=malloc((size_t)sourceLength + 1); /* Allocate new space */
        if (!*target) {
          print2("?Error: String memory couldn't be allocated\n");
          bug(104);
        }
        strcpy(*target,source);
      }

    } else {    /* source is 0 length, target is not */
      free(*target);
      *target= "";
    }
  } else {
    if (sourceLength) { /* target is 0 length, source is not */
      *target=malloc((size_t)sourceLength + 1);   /* Allocate new space */
      if (!*target) {
        print2("?Error: Could not allocate string memory\n");
        bug(105);
      }
      strcpy(*target,source);
    } else {    /* source and target are both 0 length */
      *target= "";
    }
  }

  tempAlloc(0); /* Free up temporary strings used in expression computation */

}




vstring cat(vstring string1,...)        /* String concatenation */
#define MAX_CAT_ARGS 30
{
  va_list ap;   /* Declare list incrementer */
  vstring arg[MAX_CAT_ARGS];    /* Array to store arguments */
  long argLength[MAX_CAT_ARGS]; /* Array to store argument lengths */
  int numArgs=1;        /* Define "last argument" */
  int i;
  long j;
  vstring ptr;

  arg[0]=string1;       /* First argument */

  va_start(ap,string1); /* Begin the session */
  while ((arg[numArgs++]=va_arg(ap,char *)))
        /* User-provided argument list must terminate with 0 */
    if (numArgs>=MAX_CAT_ARGS-1) {
      print2("?Error: Too many cat() arguments\n");
      bug(106);
    }
  va_end(ap);           /* End var args session */

  numArgs--;    /* The last argument (0) is not a string */

  /* Find out the total string length needed */
  j=0;
  for (i=0; i<numArgs; i++) {
    argLength[i]=(long)strlen(arg[i]);
    j=j+argLength[i];
  }
  /* Allocate the memory for it */
  ptr=tempAlloc(j+1);
  /* Move the strings into the newly allocated area */
  j=0;
  for (i=0; i<numArgs; i++) {
    strcpy(ptr+j,arg[i]);
    j=j+argLength[i];
  }
  return (ptr);

}


/* 20-Oct-2013 Wolf Lammen - allow unlimited input line lengths */
/* Input a line from the user or from a file */
/* Returns 1 if a (possibly empty) line was successfully read, 0 if EOF */
int linput(FILE *stream, const char* ask, vstring *target)
{                           /* Note: "vstring *target" means "char **target" */
  /*
    BASIC:  linput "what"; a$
    c:      linput(NULL, "what?", &a);

    BASIC:  linput #1, a$                         (error trap on EOF)
    c:      if (!linput(file1, NULL, &a)) break;  (break on EOF)

  */
  /* This function prints a prompt (if 'ask' is not NULL), gets a line from
    the stream, and assigns it to target using the let(&...) function.
    0 is returned when end-of-file is encountered.  The vstring
    *target MUST be initialized to "" or previously assigned by let(&...)
    before using it in linput. */
  char f[10001]; /* Read in chunks up to 10000 characters */
  int result = 0;
  int eol_found = 0;
  if (ask) {
    printf("%s", ask);
#if __STDC__
    fflush(stdout);
#endif
  }
  if (stream == NULL) stream = stdin;
  while (!eol_found && fgets(f, sizeof(f), stream))
  {
    size_t endpos = strlen(f) - 1;
    eol_found = (f[endpos] == '\n');
    /* If the last line in the file has no newline, eol_found will be 0 here.
       The fgets() above will return 0 and prevent another loop iteration. */
    if (eol_found)
      f[endpos] = 0; /* The return string will have any newline stripped. */
    if (result)
      /* Append additional parts of the line to *target */
      /* The let() reallocates *target and copies the concatenation of the
         old *target and the additional input f[] to it */
      let(target /* = &(*target) */, cat(*target, f, NULL));
    else
      /* This is the first time through the loop, and normally
         the only one unless the input line overflows f[] */
      let(target, f);  /* Allocate *target and copy f to it */
    result = 1;
  }
  return result;
} /* linput */


/* Find out the length of a string */
long len(vstring s)
{
  return ((long)strlen(s));
}


/* Extract sin from character position start to stop into sout */
vstring seg(vstring sin, long start, long stop)
{
  if (start < 1) start = 1;
  return mid(sin, start, stop - start + 1);
} /* seg */


/* Extract sin from character position start for length len */
vstring mid(vstring sin, long start, long length)
{
  vstring sout;
  if (start < 1) start = 1;
  if (length < 0) length = 0;
  sout=tempAlloc(length + 1);
  strncpy(sout,sin + start - 1, (size_t)length);
  sout[length] = 0;
  return (sout);
} /* mid */


/* Extract leftmost n characters */
vstring left(vstring sin,long n)
{
  return mid(sin, 1, n);
} /* left */


/* Extract after character n */
vstring right(vstring sin, long n)
{
  return seg(sin, n, (long)(strlen(sin)));
} /* right */


/* Emulate VMS BASIC edit$ command */
vstring edit(vstring sin,long control)
#define isblank_(c) ((c == ' ') || (c == '\t'))
    /* 11-Sep-2009 nm Added _ to fix '"isblank" redefined' compiler warning */
#define isblankorlf_(c) ((c == ' ') || (c == '\t') || (c == '\n'))
    /* 8-May-2015 nm added isblankorlf_ */
{
  /* EDIT$ (from VMS BASIC manual)
       Syntax:  str-vbl = EDIT$(str-exp, int-exp)
       Values   Effect
       1        Trim parity bits
       2        Discard all spaces and tabs
       4        Discard characters: CR, LF, FF, ESC, RUBOUT, and NULL
       8        Discard leading spaces and tabs
       16       Reduce spaces and tabs to one space
       32       Convert lowercase to uppercase
       64       Convert [ to ( and ] to )
       128      Discard trailing spaces and tabs
       256      Do not alter characters inside quotes

       (non-BASIC extensions)
       512      Convert uppercase to lowercase
       1024     Tab the line (convert spaces to equivalent tabs)
       2048     Untab the line (convert tabs to equivalent spaces)
       4096     Convert VT220 screen print frame graphics to -,|,+ characters

       (Added 10/24/03:)
       8192     Discard CR only (to assist DOS-to-Unix conversion)

       (Added 8-May-2015 nm:)
       16384    Discard trailing spaces, tabs, and LFs
  */
  vstring sout;
  long i, j, k, m;
  int last_char_is_blank;
  int trim_flag, discardctrl_flag, bracket_flag, quote_flag, case_flag;
  int alldiscard_flag, leaddiscard_flag, traildiscard_flag,
      traildiscardLF_flag, reduce_flag;
  int processing_inside_quote=0;
  int lowercase_flag, tab_flag, untab_flag, screen_flag, discardcr_flag;
  unsigned char graphicsChar;

  /* Set up the flags */
  trim_flag = control & 1;
  alldiscard_flag = control & 2;
  discardctrl_flag = control & 4;
  leaddiscard_flag = control & 8;
  reduce_flag = control & 16;
  case_flag = control & 32;
  bracket_flag = control & 64;
  traildiscard_flag = control & 128;
  traildiscardLF_flag = control & 16384;
  quote_flag = control & 256;

  /* Non-BASIC extensions */
  lowercase_flag = control & 512;
  tab_flag = control & 1024;
  untab_flag = control & 2048;
  screen_flag = control & 4096; /* Convert VT220 screen prints to |,-,+
                                   format */
  discardcr_flag = control & 8192; /* Discard CR's */

  /* Copy string */
  i = (long)strlen(sin) + 1;
  if (untab_flag) i = i * 7; /* Allow for max possible length */
  sout=tempAlloc(i);
  strcpy(sout,sin);

  /* Discard leading space/tab */
  i=0;
  if (leaddiscard_flag)
    while ((sout[i] != 0) && isblank_(sout[i]))
      sout[i++] = 0;

  /* Main processing loop */
  while (sout[i] != 0) {

    /* Alter characters inside quotes ? */
    if (quote_flag && ((sout[i] == '"') || (sout[i] == '\'')))
       processing_inside_quote = ~ processing_inside_quote;
    if (processing_inside_quote) {
       /* Skip the rest of the code and continue to process next character */
       i++; continue;
    }

    /* Discard all space/tab */
    if ((alldiscard_flag) && isblank_(sout[i]))
        sout[i] = 0;

    /* Trim parity (eighth?) bit */
    if (trim_flag)
       sout[i] = sout[i] & 0x7F;

    /* Discard CR,LF,FF,ESC,BS */
    if ((discardctrl_flag) && (
         (sout[i] == '\015') || /* CR  */
         (sout[i] == '\012') || /* LF  */
         (sout[i] == '\014') || /* FF  */
         (sout[i] == '\033') || /* ESC */
         /*(sout[i] == '\032') ||*/ /* ^Z */ /* DIFFERENCE won't work w/ this */
         (sout[i] == '\010')))  /* BS  */
      sout[i] = 0;

    /* Discard CR */
    if ((discardcr_flag) && (
         (sout[i] == '\015')))  /* CR  */
      sout[i] = 0;

    /* Convert lowercase to uppercase */
    /*
    if ((case_flag) && (islower(sout[i])))
       sout[i] = toupper(sout[i]);
    */
    /* 13-Jun-2009 nm The upper/lower case C functions have odd behavior
       with characters > 127, at least in lcc.  So this was rewritten to
       not use them. */
    if ((case_flag) && (sout[i] >= 'a' && sout[i] <= 'z'))
       sout[i] = (char)(sout[i] - ('a' - 'A'));

    /* Convert [] to () */
    if ((bracket_flag) && (sout[i] == '['))
       sout[i] = '(';
    if ((bracket_flag) && (sout[i] == ']'))
       sout[i] = ')';

    /* Convert uppercase to lowercase */
    /*
    if ((lowercase_flag) && (isupper(sout[i])))
       sout[i] = tolower(sout[i]);
    */
    /* 13-Jun-2009 nm The upper/lower case C functions have odd behavior
       with characters > 127, at least in lcc.  So this was rewritten to
       not use them. */
    if ((lowercase_flag) && (sout[i] >= 'A' && sout[i] <= 'Z'))
       sout[i] = (char)(sout[i] + ('a' - 'A'));

    /* Convert VT220 screen print frame graphics to +,|,- */
    if (screen_flag) {
      graphicsChar = (unsigned char)sout[i]; /* Need unsigned char for >127 */
      /* vt220 */
      if (graphicsChar >= 234 && graphicsChar <= 237) sout[i] = '+';
      if (graphicsChar == 241) sout[i] = '-';
      if (graphicsChar == 248) sout[i] = '|';
      if (graphicsChar == 166) sout[i] = '|';
      /* vt100 */
      if (graphicsChar == 218 /*up left*/ || graphicsChar == 217 /*lo r*/
          || graphicsChar == 191 /*up r*/ || graphicsChar == 192 /*lo l*/)
        sout[i] = '+';
      if (graphicsChar == 196) sout[i] = '-';
      if (graphicsChar == 179) sout[i] = '|';
    }

    /* Process next character */
    i++;
  }
  /* sout[i]=0 is the last character at this point */

  /* Clean up the deleted characters */
  for (j = 0, k = 0; j <= i; j++)
    if (sout[j]!=0) sout[k++]=sout[j];
  sout[k] = 0;
  /* sout[k] = 0 is the last character at this point */

  /* Discard trailing space/tab */
  if (traildiscard_flag) {
    --k;
    while ((k >= 0) && isblank_(sout[k])) --k;
    sout[++k] = 0;
  }

  /* 8-May-2015 nm */
  /* Discard trailing space/tab and LF */
  if (traildiscardLF_flag) {
    --k;
    while ((k >= 0) && isblankorlf_(sout[k])) --k;
    sout[++k] = 0;
  }

  /* Reduce multiple space/tab to a single space */
  if (reduce_flag) {
    i = j = last_char_is_blank = 0;
    while (i <= k - 1) {
      if (!isblank_(sout[i])) {
        sout[j++] = sout[i++];
        last_char_is_blank = 0;
      } else {
        if (!last_char_is_blank)
          sout[j++]=' '; /* Insert a space at the first occurrence of a blank */
        last_char_is_blank = 1; /* Register that a blank is found */
        i++; /* Process next character */
      }
    }
    sout[j] = 0;
  }

  /* Untab the line */
  if (untab_flag || tab_flag) {

    /*
    DEF FNUNTAB$(L$)      ! UNTAB LINE L$
    I9%=1%
    I9%=INSTR(I9%,L$,CHR$(9%))
    WHILE I9%
      L$=LEFT(L$,I9%-1%)+SPACE$(8%-((I9%-1%) AND 7%))+RIGHT(L$,I9%+1%)
      I9%=INSTR(I9%,L$,CHR$(9%))
    NEXT
    FNUNTAB$=L$
    FNEND
    */

    /***** old code (doesn't handle multiple lines)
    k = (long)strlen(sout);
    for (i = 1; i <= k; i++) {
      if (sout[i - 1] != '\t') continue;
      for (j = k; j >= i; j--) {
        sout[j + 8 - ((i - 1) & 7) - 1] = sout[j];
      }
      for (j = i; j < i + 8 - ((i - 1) & 7); j++) {
        sout[j - 1] = ' ';
      }
      k = k + 8 - ((i - 1) & 7);
    }
    *****/

    /* Untab string containing multiple lines */ /* 9-Jul-2011 nm */
    /* (Currently this is needed by outputStatement() in mmpars.c) */
    k = (long)strlen(sout);
    m = 0;  /* Position on line relative to last '\n' */
    for (i = 1; i <= k; i++) {
      if (sout[i - 1] == '\n') {
        m = 0;
        continue;
      }
      m++; /* Should equal i for one-line string */
      if (sout[i - 1] != '\t') continue;
      for (j = k; j >= i; j--) {
        sout[j + 8 - ((m - 1) & 7) - 1] = sout[j];
      }
      for (j = i; j < i + 8 - ((m - 1) & 7); j++) {
        sout[j - 1] = ' ';
      }
      k = k + 8 - ((m - 1) & 7);
    }
  }

  /* Tab the line */
  /* (Note that this does not [yet?] handle string with multiple lines) */
  if (tab_flag) {

    /*
    DEF FNTAB$(L$)        ! TAB LINE L$
    I9%=0%
    FOR I9%=8% STEP 8% WHILE I9%<LEN(L$)
      J9%=I9%
      J9%=J9%-1% UNTIL ASCII(MID(L$,J9%,1%))<>32% OR J9%=I9%-8%
      IF J9%<=I9%-2% THEN
        L$=LEFT(L$,J9%)+CHR$(9%)+RIGHT(L$,I9%+1%)
        I9%=J9%+1%
      END IF
    NEXT I9%
    FNTAB$=L$
    FNEND
    */

    k = (long)strlen(sout);
    for (i = 8; i < k; i = i + 8) {
      j = i;

      /* 25-May-2016 nm */
      /* gcc m*.c -o metamath.exe -O2 -Wall was giving:
             mmvstr.c:285:9: warning: assuming signed overflow does not occur
             when assuming that (X - c) <= X is always true [-Wstrict-overflow]
         Here we trick gcc into turning off this optimization by moving
         the computation of i - 2 here, then referencing m instead of i - 2
         below.  Note that if "m = i - 2" is moved _after_ the "while", the
         error message returns. */
      m = i - 2;

      while (sout[j - 1] == ' ' && j > i - 8) j--;
      /*if (j <= i - 2) {*/
      if (j <= m) {  /* 25-May-2016 nm */
        sout[j] = '\t';
        j = i;
        while (sout[j - 1] == ' ' && j > i - 8 + 1) {
          sout[j - 1] = 0;
          j--;
        }
      }
    }
    i = k;
    /* sout[i]=0 is the last character at this point */
    /* Clean up the deleted characters */
    for (j = 0, k = 0; j <= i; j++)
      if (sout[j] != 0) sout[k++] = sout[j];
    sout[k] = 0;
    /* sout[k] = 0 is the last character at this point */
  }

  return (sout);
} /* edit */


/* Return a string of the same character */
vstring string(long n, char c)
{
  vstring sout;
  long j=0;
  if (n<0) n=0;
  sout=tempAlloc(n+1);
  while (j<n) sout[j++]=c;
  sout[j]=0;
  return (sout);
}


/* Return a string of spaces */
vstring space(long n)
{
  return (string(n,' '));
}


/* Return a character given its ASCII value */
vstring chr(long n)
{
  vstring sout;
  sout = tempAlloc(2);
  sout[0] = (char)(n & 0xFF);
  sout[1] = 0;
  return(sout);
} /* chr */


/* Search for string2 in string1 starting at start_position */
/* If there is no match, 0 is returned */
/* If string2 is "", (length of the string) + 1 is returned */
long instr(long start_position, vstring string1, vstring string2)
{
  char *sp1, *sp2;
  long ls1, ls2;
  long found = 0;
  if (start_position < 1) start_position = 1;
  ls1 = (long)strlen(string1);
  ls2 = (long)strlen(string2);
  if (start_position > ls1) start_position = ls1 + 1;
  sp1 = string1 + start_position - 1;
  while ((sp2 = strchr(sp1, string2[0])) != 0) {
    if (strncmp(sp2, string2, (size_t)ls2) == 0) {
      found = sp2 - string1 + 1;
      break;
    } else
      sp1 = sp2 + 1;
  }
  return (found);
} /* instr */


/* Translate string in sin to sout based on table.
   Table must be 256 characters long!! <- not true anymore? */
vstring xlate(vstring sin,vstring table)
{
  vstring sout;
  long len_table,len_sin;
  long i,j;
  long table_entry;
  char m;
  len_sin=(long)strlen(sin);
  len_table=(long)strlen(table);
  sout=tempAlloc(len_sin+1);
  for (i=j=0; i<len_sin; i++)
  {
    table_entry= 0x000000FF & (long)sin[i];
    if (table_entry<len_table)
      if ((m=table[table_entry])!='\0')
        sout[j++]=m;
  }
  sout[j]='\0';
  return (sout);
}


/* Returns the ascii value of a character */
long ascii_(vstring c)
{
  return (long)((unsigned char)(c[0]));
}

/* Returns the floating-point value of a numeric string */
double val(vstring s)
{
  /*
  return (atof(s));
  */
  /* 12/10/98 - NDM - atof may corrupt memory when processing
     random character strings.
     The implementation below makes best guess of value of any
     random string, ignoring commas, etc. and tolerating numbers
     suffixed with sign.  "E" notation is not handled. */
  double v = 0;
  char signFound = 0;
  double power = 1.0;
  long i;
  /* Scan from lsd backwards to minimize rounding errors */
  for (i = (long)strlen(s) - 1; i >= 0; i--) {
    switch (s[i]) {
      case '0': case '1': case '2': case '3': case '4':
      case '5': case '6': case '7': case '8': case '9':
        v = v + ((double)(s[i] - '0')) * power;
        power = 10.0 * power;
        break;
      case '.':
        v = v / power;
        power = 1.0;
        break;
      case '-':
        signFound = 1;
        break;
    }
  }
  if (signFound) v = - v;
  return v;
}


/* Returns current date as an ASCII string */
vstring date()
{
        vstring sout;
        struct tm *time_structure;
        time_t time_val;
        char *month[12];

        /* (Aggregrate initialization is not portable) */
        /* (It must be done explicitly for portability) */
        month[0]="Jan";
        month[1]="Feb";
        month[2]="Mar";
        month[3]="Apr";
        month[4]="May";
        month[5]="Jun";
        month[6]="Jul";
        month[7]="Aug";
        month[8]="Sep";
        month[9]="Oct";
        month[10]="Nov";
        month[11]="Dec";

        time(&time_val);                        /* Retrieve time */
        time_structure=localtime(&time_val); /* Translate to time structure */
        sout=tempAlloc(12);
        /* "%02d" means leading zeros with min. field width of 2 */
        sprintf(sout,"%d-%s-%02d",
                time_structure->tm_mday,
                month[time_structure->tm_mon],
                (int)((time_structure->tm_year) % 100)); /* Y2K */
        return(sout);
}

/* Return current time as an ASCII string */
vstring time_()
{
        vstring sout;
        struct tm *time_structure;
        time_t time_val;
        int i;
        char *format;
        char *format1="%d:%d %s";
        char *format2="%d:0%d %s";
        char *am_pm[2];
        /* (Aggregrate initialization is not portable) */
        /* (It must be done explicitly for portability) */
        am_pm[0]="AM";
        am_pm[1]="PM";

        time(&time_val);                        /* Retrieve time */
        time_structure=localtime(&time_val); /* Translate to time structure */
        if (time_structure->tm_hour>=12) i=1;
        else                             i=0;
        if (time_structure->tm_hour>12) time_structure->tm_hour-=12;
        if (time_structure->tm_hour==0) time_structure->tm_hour=12;
        sout=tempAlloc(12);
        if (time_structure->tm_min>=10)
          format=format1;
        else
          format=format2;
        sprintf(sout,format,
                time_structure->tm_hour,
                time_structure->tm_min,
                am_pm[i]);
        return(sout);

}


/* Return a number as an ASCII string */
vstring str(double f)
{
  /* This function converts a floating point number to a string in the */
  /* same way that %f in printf does, except that trailing zeroes after */
  /* the one after the decimal point are stripped; e.g., it returns 7 */
  /* instead of 7.000000000000000. */
  vstring s;
  long i;
  s = tempAlloc(50);
  sprintf(s, "%f", f);
  if (strchr(s, '.') != 0) {              /* the string has a period in it */
    for (i = (long)strlen(s) - 1; i > 0; i--) { /* scan string backwards */
      if (s[i] != '0') break;             /* 1st non-zero digit */
      s[i] = 0;                           /* delete the trailing 0 */
    }
    if (s[i] == '.') s[i] = 0;            /* delete trailing period */
  }
  return (s);
}


/* Return a number as an ASCII string */
vstring num1(double f)
{
  return (str(f));
}


/* Return a number as an ASCII string surrounded by spaces */
vstring num(double f)
{
  return (cat(" ",str(f)," ",NULL));
}


/*** NEW FUNCTIONS ADDED 11/25/98 ***/

/* Emulate PROGRESS "entry" and related string functions */
/* (PROGRESS is a 4-GL database language) */

/* A "list" is a string of comma-separated elements.  Example:
   "a,b,c" has 3 elements.  "a,b,c," has 4 elements; the last element is
   an empty string.  ",," has 3 elements; each is an empty string.
   In "a,b,c", the entry numbers of the elements are 1, 2 and 3 (i.e.
   the entry numbers start a 1, not 0). */

/* Returns a character string entry from a comma-separated
   list based on an integer position. */
/* If element is less than 1 or greater than number of elements
   in the list, a null string is returned. */
vstring entry(long element, vstring list)
{
  vstring sout;
  long commaCount, lastComma, i, length;
  if (element < 1) return ("");
  lastComma = -1;
  commaCount = 0;
  i = 0;
  while (list[i] != 0) {
    if (list[i] == ',') {
      commaCount++;
      if (commaCount == element) {
        break;
      }
      lastComma = i;
    }
    i++;
  }
  if (list[i] == 0) commaCount++;
  if (element > commaCount) return ("");
  length = i - lastComma - 1;
  if (length < 1) return ("");
  sout = tempAlloc(length + 1);
  strncpy(sout, list + lastComma + 1, (size_t)length);
  sout[length] = 0;
  return (sout);
}


/* Emulate PROGRESS lookup function */
/* Returns an integer giving the first position of an expression
   in a comma-separated list. Returns a 0 if the expression
   is not in the list. */
long lookup(vstring expression, vstring list)
{
  long i, exprNum, exprPos;
  char match;

  match = 1;
  i = 0;
  exprNum = 0;
  exprPos = 0;
  while (list[i] != 0) {
    if (list[i] == ',') {
      exprNum++;
      if (match) {
        if (expression[exprPos] == 0) return exprNum;
      }
      exprPos = 0;
      match = 1;
      i++;
      continue;
    }
    if (match) {
      if (expression[exprPos] != list[i]) match = 0;
    }
    i++;
    exprPos++;
  }
  exprNum++;
  if (match) {
    if (expression[exprPos] == 0) return exprNum;
  }
  return 0;
}


/* Emulate PROGRESS num-entries function */
/* Returns the number of items in a comma-separated list. */
/* If the input string is empty, 0 is returned. */
long numEntries(vstring list)
{
  long i, commaCount;
  i = 0;
  commaCount = 0;
  if (list[0] == 0) return 0;
  while (list[i] != 0) {
    if (list[i] == ',') commaCount++;
    i++;
  }
  return (commaCount + 1);
}

/* Returns the character position of the start of the
   element in a list - useful for manipulating
   the list string directly.  1 means the first string
   character. */
/* If element is less than 1 or greater than number of elements
   in the list, a 0 is returned.  If entry is null, a 0 is
   returned. */
long entryPosition(long element, vstring list)
{
  long commaCount, lastComma, i;
  if (element < 1) return 0;
  lastComma = -1;
  commaCount = 0;
  i = 0;
  while (list[i] != 0) {
    if (list[i] == ',') {
      commaCount++;
      if (commaCount == element) {
        break;
      }
      lastComma = i;
    }
    i++;
  }
  if (list[i] == 0) {
    if (i == 0) return 0;
    if (list[i - 1] == ',') return 0;
    commaCount++;
  }
  if (element > commaCount) return (0);
  if (list[lastComma + 1] == ',') return 0;
  return (lastComma + 2);
}


void print2(char* fmt,...)
{
  /* This performs the same operations as printf, except that if a log file is
    open, the characters will also be printed to the log file. */
  va_list ap;
  char printBuffer[10001];

  va_start(ap, fmt);
  vsprintf(printBuffer, fmt, ap); /* Put formatted string into buffer */
  va_end(ap);

  printf("%s", printBuffer); /* Terminal */

  if (fplog != NULL) {
    fprintf(fplog, "%s", printBuffer);  /* Print to log file */
  }
  return;
}

/* Opens files with error message; opens output files with
   backup of previous version.   Mode must be "r" or "w". */
FILE *fSafeOpen(vstring fileName, vstring mode)
{
  FILE *fp;
  vstring prefix = "";
  vstring postfix = "";
  vstring bakName = "";
  vstring newBakName = "";
  long v;

  if (!strcmp(mode, "r")) {
    fp = fopen(fileName, "r");
    if (!fp) {
      print2("?Sorry, couldn't open the file \"%s\".\n", fileName);
    }
    return (fp);
  }

  if (!strcmp(mode, "w")) {
    /* See if the file already exists. */
    fp = fopen(fileName, "r");

    if (fp) {
      fclose(fp);

#define VERSIONS 9
      /* The file exists.  Rename it. */

#if defined __WATCOMC__ /* MSDOS */
      /* Make sure file name before extension is 8 chars or less */
      i = instr(1, fileName, ".");
      if (i) {
        let(&prefix, left(fileName, i - 1));
        let(&postfix, right(fileName, i));
      } else {
        let(&prefix, fileName);
        let(&postfix, "");
      }
      let(&prefix, cat(left(prefix, 5), "~", NULL));
      let(&postfix, cat("~", postfix, NULL));
      if (0) goto skip_backup; /* Prevent compiler warning */

#elif defined __GNUC__ /* Assume unix */
      let(&prefix, cat(fileName, "~", NULL));
      let(&postfix, "");

#elif defined THINK_C /* Assume Macintosh */
      let(&prefix, cat(fileName, "~", NULL));
      let(&postfix, "");

#elif defined VAXC /* Assume VMS */
      /* For debugging on VMS: */
      /* let(&prefix, cat(fileName, "-", NULL));
         let(&postfix, "-"); */
      /* Normal: */
      goto skip_backup;

#else /* Unknown; assume unix standard */
      /*if (1) goto skip_backup;*/  /* [if no backup desired] */
      let(&prefix, cat(fileName, "~", NULL));
      let(&postfix, "");

#endif


      /* See if the lowest version already exists. */
      let(&bakName, cat(prefix, str(1), postfix, NULL));
      fp = fopen(bakName, "r");
      if (fp) {
        fclose(fp);
        /* The lowest version already exists; rename all to lower versions. */

        /* If version VERSIONS exists, delete it. */
        let(&bakName, cat(prefix, str(VERSIONS), postfix, NULL));
        fp = fopen(bakName, "r");
        if (fp) {
          fclose(fp);
          remove(bakName);
        }

        for (v = VERSIONS - 1; v >= 1; v--) {
          let(&bakName, cat(prefix, str((double)v), postfix, NULL));
          fp = fopen(bakName, "r");
          if (!fp) continue;
          fclose(fp);
          let(&newBakName, cat(prefix, str((double)(v + 1)), postfix, NULL));
          rename(bakName, newBakName);
        }

      }
      let(&bakName, cat(prefix, str(1), postfix, NULL));
      rename(fileName, bakName);

      /***
      printLongLine(cat("The file \"", fileName,
          "\" already exists.  The old file is being renamed to \"",
          bakName, "\".", NULL), "  ", " ");
      ***/
    } /* End if file already exists */
   /*skip_backup:*/

    fp = fopen(fileName, "w");
    if (!fp) {
      print2("?Sorry, couldn't open the file \"%s\".\n", fileName);
    }

    let(&prefix, "");
    let(&postfix, "");
    let(&bakName, "");
    let(&newBakName, "");

    return (fp);
  } /* End if mode = "w" */

  bug(1510); /* Illegal mode */
  return(NULL);

}


/* Bug check */
void bug(int bugNum)
{
  print2("?Error: Program bug # %d\n", bugNum);
  exit(0);
}

/* End of "variable-length string handler" functions */
