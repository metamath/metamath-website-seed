#
#  mmide.py
#

import Source

if __name__ == "__main__":
    application = Source.Application()
    application.run()
