#
#  WHHorizontalLineView.py
#
#  Created by William Hale on 8/14/06.
#

import GUI

class WHHorizontalLineView(GUI.View):

    def __init__(self, **kwds):
        super(WHHorizontalLineView, self).__init__(**kwds)
        self.size = (0, 1)

    def draw(self, canvas, update_rect):
        #canvas.gsave() ### wch TESTING
        canvas.forecolor = GUI.StdColors.black
        canvas.fill_rect((0, 0, self.width, self.height))
        #canvas.grestore() ### wch TESTING
