#
#   WHGeometry.py
#

def empty_closedRect((l, t, r, b)):
    return r < l or b < t

def pt_in_closedRect((x, y), (l, t, r, b)):
    return l <= x <= r and t <= y <= b

def closedRects_intersect((l1, t1, r1, b1), (l2, t2, r2, b2)):
    return l1 <= r2 and l2 <= r1 and t1 <= b2 and t2 <= b1
