#
#  WHImage.py
#

import GUI

class WHImage(GUI.Image):

    def __init__(self, **kwds):
        super(WHImage, self).__init__(**kwds)
    
    def draw(self, canvas, src_rect, dst_rect):
        from AppKit import NSCompositeSourceAtop, NSCompositeCopy
        from GUI.Geometry import rect_to_ns_rect
        ns_src_rect = rect_to_ns_rect(src_rect)
        ns_dst_rect = rect_to_ns_rect(dst_rect)
        self._ns_image.drawInRect_fromRect_operation_fraction_(
            ns_dst_rect, ns_src_rect, NSCompositeCopy, 1.0)
