$[ set04.06.2013.mm  $]


    
    $( Clues: 9re opreq2i eqcomi recni 3eqtri 1re opreq1i addassi df-10 1p1e2 $)

    problem1 $p |-  ( 9 + 2 ) = ( 10 + 1 )   $=    $.
      
 
  
    $( Clues:  8re eqtri opreq2i eqcomi 5p2e7 addcomi recni 5re addassi opreq1i
     8p2e10 3eqtri $)

    problem2 $p |- ( 8 + 7 ) = ( 10 + 5 )  $=    $.
      