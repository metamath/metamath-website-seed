$[ set04.06.2013.mm $]


    
    $( Clues: 5p4e9 3p2e5 eqtri opreq1i $)

    problem1 $p |- ( ( 3 + 2 ) + 4 ) = 9  $=   $.
      
 
  
    $( Clues: 2p2e4 3eqtri 4p2e6 6p2e8 opreq1i $)

    problem2 $p |- ( ( ( 2 + 2 ) + 2 ) + 2 ) = 8   $=    $.
     