$[ set04.06.2013.mm $]



${

problem1.1 $e |-  A e. CC  $.

problem1.2 $e |-  ( A + 3 ) = 4 $.

$( Clues: eqcomi  eqtri  
   subaddrii recni 4re 
   3re 1re df-4 addcomi 
  problem1.1 problem1.2  
$)

problem1 $p |-  A = 1  $=     $.

$} 
  