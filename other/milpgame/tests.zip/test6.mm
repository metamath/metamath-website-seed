$[ set04.06.2013.mm $]



${

problem1.1 $e |-  A e. CC  $.

problem1.2 $e |-  B e. CC   $.

problem1.3 $e |-  ( A + B ) = 3   $.

problem1.4 $e |-  ( ( 3 x. A ) + ( 2 x. B ) ) = 7   $.

$( 
Clues: 3cn  subaddrii 2cn opreq1i  nncni
   9nn mulcli subadd23 mp3an subdiri ax-1cn subnegi eqtr4i negcli 
subsub23i df-3 mpbi mulm1i eqtri eqtr3i opreq2i negsubi 3eqtrri addcli 
addcomi 3t3e9 subdii 3eqtri 7re recni 7p2e9 eqcomi pm3.2i  
problem1.1 problem1.2 problem1.3 problem1.4   

$)

problem1 $p |- ( A = 1 /\ B = 2 )  $=      $.

$} 
  