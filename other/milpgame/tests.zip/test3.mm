$[ set04.06.2013.mm $]


$( Clues: opreq12i adddiri add4i mulcli recni 2re 3eqtri 10re 5re 1re 
4re  eqcomi 5p4e9 opreq1i df-3   $)

problem1 $p |-  ( ( ( 2 x. 10 ) + 5 ) + ( ( 1 x. 10 ) + 4 ) ) = ( ( 3 x. 10 ) + 9 ) $=   $.

 
  