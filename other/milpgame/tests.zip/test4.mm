$[ set04.06.2013.mm  $]


$( Clues: opreq2i addcomi addcli recni 1re 2re 3re eqtri 3eqtri 4re eqcomi addassi  $)

problem1 $p |-  ( ( ( 1 + 2 ) + 3 ) + 4 ) = ( ( ( 4 + 3 ) + 2 ) + 1 )  $=    $.

 
  