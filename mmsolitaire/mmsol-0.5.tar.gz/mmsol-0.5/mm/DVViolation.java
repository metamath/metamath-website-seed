package mm;

final class DVViolation extends Exception { 
    public short var;
    public DVViolation(short v) { var=v; }
}
