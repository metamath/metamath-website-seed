// mm.java Copyright (c) 2003 Norman Megill nm at alum dot mit dot edu

// Copyright under terms of GNU General Public License

// To compile on Windows:  Download and install the 1.3.1 SDK.  The setup
// file that I downloaded from java.sun.com on 14-Jun-2002 was called
// j2sdk-1_3_1_03-win.exe and its size was 44526848 bytes.  After
// installing, open the Command Prompt, cd to the directory with mm.java,
// and type
//    C:\jdk1.3.1_03\bin\javac mm.java
// Warning: If compiled with j2sdk1.4.0, the program will not run under
// the native Microsoft JVM in Internet Explorer.

// History: 5-Aug-1997   Initial release
//          13-Apr-2001  Upgraded to Java 2 by Marcello DeMarinis
//          5-Jun-2002   Fixed "Save As Axiom" bug that incorrectly suppressed
//                       user-created theorems from the list of choices when
//                       the proof of the theorem contained hypotheses
//          7-Aug-2003   Fixed typos in Euclid's axioms eu8 and eu3
//                       (found by Russell O'Connor)

// Note:  I have included the entire program in one file (contrary to
// recommended Java programming guidelines) as I believe this is more
// convenient for distribution.  Also, the main class mm is not upper-case
// (contrary to recommended Java programming guidelines) because I got tired
// of shifting; thus this file must be called mm.java, not MM.java nor Mm.java.

import java.applet.*;
import java.awt.*;
import java.util.*;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

@SuppressWarnings("serial")
    public class mm extends Applet implements ActionListener, ItemListener {

	//private Button clear_button;
	private Choice option_choices;
	static boolean proofInfoModeFlag = false;
	private Button proof_exit_button;
	static boolean axiomInfoModeFlag = false;
	static boolean selectLogicModeFlag = false;
	static int infoModeAxiomToShow;
	private Button info_exit_button;

	private Choice axiom_choices;
	private Label axiom_label = new Label("Axioms:", Label.RIGHT);
	private ArrayList<Integer> axiomChoiceVec;

	private TextArea proof_text;


	// Current state of stack
	static State currentState;

	// Undo/redo variables
	static Stack<State> undoStack;
	static Stack<State> redoStack; // (Future - not implemented yet - NDM)

	// Connective storage
	static Connective[] connectiveArr;
	static String connectiveLabels; // For speedup
	static String connectiveLabelMap; // For speedup

	// Axiom storage
	static final int FAMILIES = 13;
	@SuppressWarnings("unchecked")
	    static final ArrayList<Axiom>[] axiomFamily = new ArrayList[FAMILIES];
  
	static final int PROP_CALC = 0;
	static final int PROP_DEFS = 1;
	static final int PRED_CALC = 2;
	static final int PRED_DEFS = 3;
	static final int SET_THEORY = 4;
	static final int SET_DEFS = 5;
	static final int IMPL_LOGIC = 6;
	static final int INTUIT_LOGIC = 7;
	static final int MODAL_LOGIC = 8;
	static final int GODEL_LOGIC = 9;
	static final int QUANTUM_LOGIC = 10;
	static final int EUCLID = 11;
	static final int WEAKD_LOGIC = 12;
  
	static final String[] familyName = {
	    "Propositional Calculus",
	    "Propositional Calculus + Definitions",
	    "Predicate Calculus",
	    "Predicate Calculus + Definitions",
	    "ZFC Set Theory",
	    "ZFC Set Theory + Definitions",
	    "Implicational Logic",
	    "Intuitionist Propositional Calculus",
	    "Modal Logic",
	    "Modal Provability Logic",
	    "Quantum Logic",
	    "Euclidean Geometry",
	    "Weak D-Complete Logic"
	};
  
	static final String[] axFiles = {
	    "propcalc.txt",
	    "propdefs.txt",
	    "predcalc.txt",
	    "preddefs.txt",
	    "settheory.txt",
	    "setdefs.txt",
	    "impl.txt",
	    "ipc.txt",
	    "modal.txt",
	    "godel.txt",
	    "quantum.txt",
	    "euclid.txt",
	    "weakd.txt"
	};
  
	static final String[][] EXTRA_INFO = {
	    {"Example:  ax-1, ax-1, ax-2, ax-mp, ax-mp proves (P->P)."},
	    {"Example:  ax-1, ax-1, ax-2, ax-mp, ax-mp proves (P->P)."},
	    {},
	    {},
	    {},
	    {},
	    {"Reference:  R. Hindley and D. Meredith, J. Symb. Logic 55, 90-105 (1990)"},
	    {"Reference:  T. Thatcher Robinson, J. Symb. Logic 33, 265-270 (1968)"},
	    {"Reference:  http://www-formal.stanford.edu/pub/jmc/mcchay69/node22.html"},
	    {"Reference:  G. Boolos and R. Jeffrey, Computability and Logic (1989), ch. 27"},
	    {"Reference:  M. Pavicic, Int. J. of Theoretical Physics 32, 1481-1505 (1993)"},
	    {"For Euclidean geometry, Bxyz means \"y lies between x and z\", and Dxyzw means",
	     "\"x is as distant from y as z is from w\".",
	     "",
	     "Reference:  A. Tarski, in The Axiomatic Method (ed. Henkin et. al.) (1959), p. 19"},
	    {"Reference:  http://www.mpi-sb.mpg.de/igpl/Bulletin/V4-2/#Megill"},
	};
  
	static int currentFamily; // Current family
	static Axiom[] axiomArr; // Current axiom set
	static ArrayList<Axiom> userTheorems; // ArrayList of State

	static final private String CONNECTIVES_FILE="connectives.txt";
  
	private Checkbox[] logic_select = new Checkbox[FAMILIES];

	static int maxAxiomHyps; // set by axiom with the most hypotheses

	static final Color DARK_GREEN = new Color(0, 100, 0);
	static final Color BACKGROUND_COLOR = new Color(210, 255, 255);
	static final Color PROOF_BACKGROUND_COLOR = new Color(255, 255, 165);
	static final Color INFO_BACKGROUND_COLOR = new Color(255, 210, 255);

	// Font parameters
	static final int FONT_SIZE = 12;
	static final String MATH_FONT_NAME = "Courier"; // math variables & ASCII symbols
	static final Font MATH_FONT = new Font(MATH_FONT_NAME, Font.PLAIN, FONT_SIZE);
	static final int Y_INCREMENT = (FONT_SIZE * 3) / 2; // Line-to-line spacing
	static final int X_INIT = FONT_SIZE / 2; // Left margin
	static final int CHAR_SPACE = -1; // Space between chars of token
	static final int WHITE_SPACE = 2; // Space between tokens
	static int currentX;
	static int currentY;

	/* Do preprocessing on the input. Returns the first line that
	 * is non-empty after removing comments and excess whitespace.
	 * Returns null for EOF.
	 */
	private String nextLine(BufferedReader in) throws IOException {
	    String res="";
	    while(res.equals("")) {
		res=in.readLine();
		if(res==null) return null;
		res=res.replaceAll("#.*","").trim(); 
	    }
	    return res;
	}
  
	/* Read in connectives from connectives.txt. The format of the
	 * file is as follows: each line contains
	 * four whitespace-seperated elements, viz: the connective's
	 * name, its type, the number of arguments it takes, and its printname.
	 * The next nargs lines after that are the types of each argument.
	 */
	private Connective[] readConnectives() throws IOException {
	    ArrayList<Connective> res=new ArrayList<Connective>();
	    BufferedReader in=new BufferedReader(new FileReader(CONNECTIVES_FILE));
	  
	    for(String curConn=nextLine(in); curConn!=null; curConn=nextLine(in)) {
		String[] args=curConn.split("\\s+",4);
		String name=args[0], type=args[1], pname=args[3];
		int nargs=Integer.parseInt(args[2]);
		Connective tmp=new Connective(name,type,nargs,pname);
		for(int i=0; i<nargs; i++) tmp.setArgtype(i,nextLine(in));
		res.add(tmp);
	    }
	  
	    in.close();
	    return res.toArray(new Connective[res.size()]);
	}
  
	/* Read in axioms from the given file. File format is as follows:
	 * each line contains four whitespace-seperated elements, viz: the
	 * axiom's name, the number of hypothesies it requires, the number of
	 * distinct variable pairs it imposes, and its assertion. Following
	 * this line, there are a series of lines for the format of the hypotheses,
	 * followed by a series of lines specifying DV pairs.
	 */
	private ArrayList<Axiom> readAxioms(String filename) throws IOException {
	    ArrayList<Axiom> res=new ArrayList<Axiom>();
	    BufferedReader in=new BufferedReader(new FileReader(filename));
	  
	    for(String curAx=nextLine(in); curAx!=null; curAx=nextLine(in)) {
		String descr=nextLine(in);
		String[] args=curAx.split("\\s+",4);
		String name=args[0], assertion=args[3];
		int nhyps=Integer.parseInt(args[1]), dvPairs=Integer.parseInt(args[2]);
		Axiom tmp=new Axiom(name,assertion,descr);
		for(int i=0; i<nhyps; i++) tmp.addHyp(nextLine(in));
		for(int i=0; i<dvPairs; i++) {
		    tmp.addDistinct(nextLine(in));
		}
		res.add(tmp);
	    }
	  
	    in.close();
	    return res;
	}
  
	public void init() {

	    userTheorems = new ArrayList<Axiom>();
	    currentFamily = PROP_CALC;
	    currentState = new State();
	    undoStack = new Stack<State>();
	    redoStack = new Stack<State>();

	    try { connectiveArr = readConnectives(); }
	    catch(IOException e) { }

	    // Build connective label and map strings for faster lookup
	    connectiveLabels = " ";
	    connectiveLabelMap = "";
	    for (int i = 0; i < connectiveArr.length; i++) {
		connectiveLabels += connectiveArr[i] + " ";
		// Only the valueOf will be used; the other characters are placeholders
		connectiveLabelMap += String.valueOf((char)i) + connectiveArr[i];
	    }
    
	    try { for(int i=0; i<FAMILIES; i++) axiomFamily[i]=readAxioms(axFiles[i]); }
	    catch(IOException e) { }

	    // Determine the largest number of hypotheses
	    maxAxiomHyps = 0;
	    for (ArrayList<Axiom> axFam : axiomFamily) {
		for (Axiom ax : axFam) {
		    maxAxiomHyps = Math.max(maxAxiomHyps, ax.axHypVec.size());
		}
	    }

	    // Initialize to prop calc
	    axiomArr = buildAxiomArr(currentFamily);

	    // Set the background color
	    this.setBackground(BACKGROUND_COLOR);
    
	    proof_exit_button = new Button("Hide Proof Information");
	    proof_exit_button.setActionCommand("proof_exit_button");
	    proof_exit_button.addActionListener(this);

	    info_exit_button = new Button("Exit Axiom Information");
	    info_exit_button.setActionCommand("info_exit_button");
	    info_exit_button.addActionListener(this);

	    // Create option selection menu
	    buildOptionChoices();

	    // Create axiom selection menu
	    buildAxiomChoices();

	} // init

	// Builds the axiomArr array based on the chosen logic familiy
	// and adds to it all user theorems that are valid in that
	// logic family
	static final Axiom[] buildAxiomArr(int logicFamily) {
	    ArrayList<Axiom> axiomVec = new ArrayList<Axiom>(axiomFamily[logicFamily]);

	    // Build a string with all axiom labels
	    String axiomLabels = " ";
	    if (userTheorems.size() != 0) { // Only build label list if it will be used
		for (Axiom ax : axiomVec) axiomLabels += ax + " ";
	    }

	    // For each user theorem, accept it only if all steps of each proof
	    // are in the axiomLabels string
	    for (int i = 0; i < userTheorems.size(); i++) {
		Axiom userTh = userTheorems.get(i);
		String userProof = " " + userTh.proof + " ";
		int position0 = 1;
		int position = userProof.indexOf(' ', position0);
		boolean validProof = true;
		while (position != -1) {
		    String userProofStepLabel = userProof.substring(position0 - 1,
								    position + 1);
		    if (axiomLabels.indexOf(userProofStepLabel) == -1
			// 5-Jun-2002 (ndm) The condition below was added in case the
			//   users proof contains hypotheses.
			&& userProofStepLabel.charAt(1) != '$')
			// The userProofStepLabel is surrounded by spaces, so we match
			//     $hypnn starting at position 1, not 0
			// future: make sure that $ is not allowed in user theorem
			// names if an enhancement is made to accept user names
			{
			    // If it's not an axiom or hypothesis, it's not a valid theorem for
			    // this logic family, so we don't put it in the list of choices
			    // available to the user.
			    validProof = false;
			    break;
			}
		    position0 = position + 1;
		    position = userProof.indexOf(' ', position0);
		}
		if (validProof) {
		    axiomVec.add(0, userTh);
		    // Add label since a later proof could use it
		    axiomLabels += userTh + " ";
		}
	    } // for i
	    Axiom[] axArr = new Axiom[axiomVec.size()];
	    axiomVec.toArray(axArr);
	    return axArr;
	}

	public void actionPerformed(ActionEvent e) {

	    if (e.getActionCommand().equals("proof_exit_button")) {

		this.remove(proof_text);
		this.remove(proof_exit_button);
		proofInfoModeFlag = false;

		// Rebuild options
		buildOptionChoices();
		// Rebuild axiom selection menu and redisplay choice
		buildAxiomChoices();
		// Repaint screen
		paint(this.getGraphics());

	    } else if (e.getActionCommand().equals("info_exit_button")) {

		this.setBackground(BACKGROUND_COLOR);
		this.remove(info_exit_button);
		axiomInfoModeFlag = false;

		// Rebuild options
		buildOptionChoices();
		// Rebuild axiom selection menu and redisplay choice
		buildAxiomChoices();
		// Repaint screen
		paint(this.getGraphics());

	    }

	}

	public void itemStateChanged(ItemEvent e) {

	    if (e.getItemSelectable() == option_choices) {

		boolean rebuildFlag = false;

		if (e.getItem() == "Undo") {

		    redoStack.push(currentState.makeClone());
		    currentState = (State)(undoStack.pop());
		    userTheorems = currentState.userThVec;
		    currentFamily = currentState.currentFam;
		    axiomArr = buildAxiomArr(currentFamily);
		    rebuildFlag = true;

		} else if (e.getItem() == "Redo") {
		    undoStack.push(currentState.makeClone());
		    currentState = (State)(redoStack.pop());
		    rebuildFlag = true;
		} else if (e.getItem() == "Rotate Stack" || e.getItem() == "Swap Stack Top") {
		    undoStack.push(currentState.makeClone()); redoStack = new Stack<State>();
		    int iEnd = currentState.assertVec.size() - 1;
		    int iStart;
		    if (e.getItem() == "Rotate Stack") {
			iStart = 0;
		    } else {
			iStart = iEnd - 1;
		    }
		    String tmpStr = currentState.assertVec.get(iStart);
		    String tmpPStr = currentState.proofVec.get(iStart);
		    for (int j = iStart; j < iEnd; j++) {
			currentState.assertVec.set(j,
						   currentState.assertVec.get(j + 1));
			currentState.proofVec.set(j,
						  currentState.proofVec.get(j + 1));
		    }
		    currentState.assertVec.set(iEnd, tmpStr);
		    currentState.proofVec.set(iEnd, tmpPStr);
		    rebuildFlag = true;
		} else if (e.getItem() == "Delete Stack Top") {
		    undoStack.push(currentState.makeClone()); redoStack = new Stack<State>();
		    currentState.assertVec.remove(
						  currentState.assertVec.size() - 1);
		    currentState.proofVec.remove(
						 currentState.proofVec.size() - 1);
		    // normalize to trim any distinct variable pairs that become unused
		    currentState.normalize();
		    rebuildFlag = true;
		} else if (e.getItem() == "Erase Stack") {
		    undoStack.push(currentState.makeClone()); redoStack = new Stack<State>();
		    currentState = new State();
		    rebuildFlag = true;
		} else if (e.getItem() == "Erase All") {
		    undoStack.push(currentState.makeClone()); redoStack = new Stack<State>();
		    userTheorems = new ArrayList<Axiom>();
		    currentState = new State();
		    currentFamily = PROP_CALC;
		    axiomArr = buildAxiomArr(currentFamily);
		    rebuildFlag = true;
		    //paint(this.getGraphics());
		} else if (e.getItem() == "Proof Information") {
		    proofInfoModeFlag = true;
		    rebuildFlag = true; // Need to rebuild option choice & display proof
		} else if (e.getItem() == "Axiom Information") {
		    axiomInfoModeFlag = true;
		    infoModeAxiomToShow = -1; // means no axiom selected by user yet
		    rebuildFlag = true; // We will re-paint in this special mode
		    this.setBackground(INFO_BACKGROUND_COLOR);
		} else if (e.getItem() == "Select Logic Family") {
		    this.removeAll();
		    CheckboxGroup cg = new CheckboxGroup();
		    for (int i = 0; i < FAMILIES; i++) {
			boolean enable;
			if (i == currentFamily) enable = true; else enable = false;
			logic_select[i] = new Checkbox(familyName[i], cg, enable);
			this.add(logic_select[i]);
			logic_select[i].addItemListener(this);
		    }
		    selectLogicModeFlag = true;

		    paint(this.getGraphics());
		} else if (e.getItem() == "Add Hypothesis") {
		    undoStack.push(currentState.makeClone()); redoStack = new Stack<State>();
		    currentState.addHyp();
		    rebuildFlag = true;
		} else if (e.getItem() == "Save as Axiom") {
		    undoStack.push(currentState.makeClone()); redoStack = new Stack<State>();
		    // Save theorem at stack top as a new axiom - must rebuild array
		    // with greater bound
		    userTheorems.add(new Axiom(currentState));
		    currentState.userThVec = userTheorems;
		    axiomArr = buildAxiomArr(currentFamily);
		    // Update the largest number of hypotheses
		    maxAxiomHyps = Math.max(maxAxiomHyps, axiomArr[0].axHypVec.size());
		    // Re-display screen so user's new axiom will become an axiom pick
		    rebuildFlag = true;
		} else if (e.getItem() == "Refresh Screen") {
		    rebuildFlag = true;
		}

		if (rebuildFlag) {
		    buildOptionChoices();
		    buildAxiomChoices();

		    // If in display proof mode, put proof after choice
		    if (proofInfoModeFlag) {
			proof_text = new TextArea(
						  "The top stack entry is:\n\n",
						  20, 65);
			// Future: in Java 1.1 add: , SCROLLBARS_VERTICAL_ONLY);
			proof_text.append("    " + PrimFormula.getDisplay(currentState.assertVec.get(currentState.assertVec.size()-1)));
			proof_text.append(
					  "\n\nTo reconstruct the"
					  + " top stack entry, enter axioms in this order:\n\n");
			proof_text.append("    " +
					  currentState.proofVec.get(currentState.proofVec.size()-1));
			proof_text.setBackground(PROOF_BACKGROUND_COLOR);

			// Display fleshed-out proof detail
			proof_text.append("\n\nDetailed proof:\n\n");
			State proofInfoState = State.buildProofInfoState(currentState);
			for (int i = 0; i < proofInfoState.assertVec.size(); i++) {
			    proof_text.append(" " + proofInfoState.proofVec.get(i) + "    "
					      + PrimFormula.getDisplay(proofInfoState.assertVec.get(i)) + "\n");
			}
			if (proofInfoState.dVarVec.size() > 0) {
			    proof_text.append("\nDistinct variable pairs for this proof:\n\n");
			    for (String dv : proofInfoState.dVarVec) {
				proof_text.append("   ");
				for (int j = 0; j < 2; j++) {
				    short v = (short)(dv.charAt(j));
				    // We assume type is already assigned, so 0 is OK
				    proof_text.append(VariableName.name(v, (short)0) + " ");
				}
			    }
			}

			this.add(proof_text);
		    }

		    // Repaint screen
		    paint(this.getGraphics());
		}

	    } else if (e.getItemSelectable() == axiom_choices) {

		int choice;
		// Lookup what the choice corresponds to
		choice = axiomChoiceVec.get(axiom_choices.getSelectedIndex());

		if (axiomInfoModeFlag) {
		    infoModeAxiomToShow = choice;
		} else {
		    if (choice < 0) {
			// Push undo stack
			undoStack.push(currentState.makeClone()); redoStack = new Stack<State>();
			// It's a hypothesis; add it to the assertion stack
			currentState.pushAssertion(currentState.hypVec.get(- choice - 1),
						   // The proof is one step, just the hypothesis
						   "$hyp" + String.valueOf(- choice));
		    } else {

			// Push undo stack - no need to clone since unify does this
			undoStack.push(currentState); redoStack = new Stack<State>();
			// It's a axiom - it will always unify since that was determined
			// when choice list was built
			currentState = Unification.unify(axiomArr[choice], currentState,
							 false);
			// Squish down variables and trim unused distinct var pairs
			currentState.normalize();
		    }

		    // Rebuild option selection
		    buildOptionChoices();

		    // Rebuild axiom selection menu and redisplay choice
		    buildAxiomChoices();

		} // not info mode

		// (If it's info mode, menus will not change until we exit it; no need
		// to rebuild)

		// Repaint screen
		paint(this.getGraphics());

		// end if (event.target == axiom_choices)

	    } else {
		for (int i = 0; i < FAMILIES; i++) {

		    if (e.getItemSelectable() == logic_select[i]) {

			selectLogicModeFlag = false;
			if (currentFamily != i) {
			    // User selected a new logic family
			    undoStack.push(currentState.makeClone()); redoStack = new Stack<State>();
			    currentFamily = i;
			    axiomArr = buildAxiomArr(currentFamily);
			    currentState = new State();
			}

			// Rebuild option selection
			buildOptionChoices();

			// Rebuild axiom selection menu and redisplay choice
			buildAxiomChoices();

			// Repaint screen
			paint(this.getGraphics());
		    }
		}
	    }
	}


	// Build list of choices from axiom menu
	void buildOptionChoices() {

	    // Remove everything at once for less display glitches
	    this.removeAll();

	    if (proofInfoModeFlag) {
		this.add(proof_exit_button);
		return;
	    } else if (axiomInfoModeFlag) {
		this.add(info_exit_button);
		return;
	    } else {
		option_choices = new Choice();

		option_choices.addItemListener(this);

		if (!undoStack.empty()) option_choices.addItem("Undo");
		if (currentState.assertVec.size() > 1) {
		    option_choices.addItem("Swap Stack Top");
		    option_choices.addItem("Rotate Stack");
		}
		if (!currentState.assertVec.isEmpty()) option_choices.addItem("Delete Stack Top");
		if (!(currentState.assertVec.isEmpty() && currentState.hypVec.isEmpty())) option_choices.addItem("Erase Stack");

		if (!currentState.assertVec.isEmpty()) option_choices.addItem("Proof Information");
		option_choices.addItem("Axiom Information");
		option_choices.addItem("Add Hypothesis");
		option_choices.addItem("Select Logic Family");
		if (currentState != null && currentState.assertVec.size() > 0) {
		    option_choices.addItem("Save as Axiom");
		}
		// User workaround for Java graphics bugs
		option_choices.addItem("Refresh Screen");
	    }
	    this.add(option_choices);
	} // Build option choices

	// Build list of choices from axiom menu
	void buildAxiomChoices() {
	    State dummyState;
	    String menuString = "";
	    String menuFormula = "";

	    if (proofInfoModeFlag) return; // Disable selection in proof display mode

	    axiom_label.setBackground(axiomInfoModeFlag ? INFO_BACKGROUND_COLOR : BACKGROUND_COLOR);

	    this.add(axiom_label);
	    axiomChoiceVec = new ArrayList<Integer>();
	    axiom_choices = new Choice();

	    axiom_choices.addItemListener(this);

	    if (currentState.hypVec.size() != 0) {
		// If there are hypotheses, do a dummy run-thru of assertions and
		// hypotheses to get desired variable names for axiom choice menu
		VariableName.init();
		for (int i = currentState.assertVec.size() - 1; i >= 0; i--) {
		    PrimFormula.getDisplay(currentState.assertVec.get(i));
		}
		for (int i = currentState.hypVec.size() - 1; i >= 0; i--) {
		    PrimFormula.getDisplay(currentState.hypVec.get(i));
		}
	    }

	    // Put any user hypotheses first
	    // Variable names have not been reinitialized here; we want to use
	    // the names in the currentState display for best user info
	    if (!axiomInfoModeFlag) {
		for (int i = 0; i < currentState.hypVec.size(); i++) {
		    menuString = "1 $hyp" + String.valueOf(i + 1) + " " +
			PrimFormula.getDisplay(currentState.hypVec.get(i));
		    axiom_choices.addItem(menuString);
		    axiomChoiceVec.add(-i-1);
		}
	    }

	    // For each axiom, if it unifies with the state stack, add it in
	    // Scan in reverse order of number of hypotheses, so axioms that reduce
	    // stack the most will be displayed first
	    // Note: in info mode we show *all* axioms in their natural order, whether
	    // or not they unify
	    for (int hyps = maxAxiomHyps; hyps >= 0; hyps--) {
		if (axiomInfoModeFlag && hyps > 0) continue;
		for (int i = 0; i < axiomArr.length; i++) {
		    if (!axiomInfoModeFlag &&
			axiomArr[i].axHypVec.size() != hyps) continue;
		    if (hyps == 0) { // (or axiomInfoModeFlag - see continue logic above)
			// If there are no hypotheses, don't bother to unify for speedup
			menuString = axiomArr[i].menuEntry; // use pre-computed entry for speed
		    } else {
			dummyState = Unification.unify(axiomArr[i], currentState, false);
			if (dummyState == null) continue; // Unification not possible
			menuFormula = dummyState.getStackTop();
			VariableName.init(); // Initialize so types don't get mixed up
			// Show how much stack will grow, name of axiom, & the top of the
			// stack that would result
			menuString = String.valueOf(1 - hyps) + " " + axiomArr[i] + " " + PrimFormula.getDisplay(menuFormula);
		    }
		    axiom_choices.addItem(menuString);
		    axiomChoiceVec.add(i);
		} /* next i */
	    } /* next hyps */
	    this.add(axiom_choices);
	}

	public void paint(Graphics g) {

	    String token;
	    FontMetrics fm;

	    // validate makes an added Component show up in the display
	    // (not documented in Java spec?)
	    this.validate();

	    VariableName.init(); // Initialize so types don't get mixed up

	    // Clear screen
	    Rectangle r = this.getBounds();
	    g.setColor(this.getBackground());
	    g.fillRect(r.x, r.y, r.width, r.height);

	    currentX = X_INIT;
	    currentY = 3 * Y_INCREMENT;

	    // Display title
	    g.setFont(new Font("Dialog", Font.PLAIN, FONT_SIZE));
	    // Apply watermark to background
	    // \u00a9 = copyright symbol
	    token = "Metamath Solitaire \u00a9 2003 (GPL) Norman Megill nm" +
		"@" +
		"alum.mit.edu";
	    if (axiomInfoModeFlag) {
		g.setColor(Color.magenta);
	    } else {
		g.setColor(Color.cyan);
	    }
	    fm = g.getFontMetrics();
	    g.drawString(token, (r.width - fm.stringWidth(token))/2, r.height - 10);

	    // Display type colors
	    g.setFont(new Font("Dialog", Font.PLAIN, FONT_SIZE));
	    g.setColor(Color.black);
	    if (selectLogicModeFlag) {
		token = "Click on the logic family you want to use.";
		g.drawString(token, (r.width - fm.stringWidth(token))/2, r.height / 2);
		return;
	    }

	    g.setFont(new Font("Dialog", Font.BOLD, FONT_SIZE));
	    token = familyName[currentFamily];
	    g.drawString(token, X_INIT, currentY);
	    fm = g.getFontMetrics();
	    currentX += fm.stringWidth(token) + 2 * FONT_SIZE;
	    g.setFont(new Font("Dialog", Font.PLAIN, FONT_SIZE));

	    if (axiomInfoModeFlag && infoModeAxiomToShow == -1) {
		currentY = 5 * Y_INCREMENT;
		// User has not selected an axiom yet
		token =
		    "To see information about an axiom, choose it from the 'Axioms' menu.";
		g.drawString(token, X_INIT, currentY);
		return;
	    }
	    if (!axiomInfoModeFlag && currentState.assertVec.isEmpty()
		&& currentState.hypVec.isEmpty()) {
		// There is nothing to display yet.  Just after startup or erase.
		currentY = 5 * Y_INCREMENT;
		g.drawString(
			     "The 'Axioms' menu shows how much the stack will grow, the axiom name,",
			     X_INIT, currentY); currentY += Y_INCREMENT;
		g.drawString(
			     "and as much of the axiom as can be displayed.",
			     X_INIT, currentY);  currentY += 2 * Y_INCREMENT;
		g.drawString(
			     "Select repeatedly from the 'Axioms' menu.  The stack will grow and shrink",
			     X_INIT, currentY); currentY += Y_INCREMENT;
		g.drawString(
			     "with theorems.  The goal is to end up with a single stack entry containing",
			     X_INIT, currentY); currentY += Y_INCREMENT;
		g.drawString(
			     "a nice theorem.  You can clip out its proof with 'Proof Information'.",
			     X_INIT, currentY); currentY += 2 * Y_INCREMENT;
     
		for(String line : EXTRA_INFO[currentFamily]) {
		    g.drawString(line, X_INIT, currentY);
		    currentY+=Y_INCREMENT;
		}
		return;
	    }
	    token = "Colors of variable types:";
	    g.drawString(token, currentX, currentY);
	    fm = g.getFontMetrics();
	    currentX += fm.stringWidth(token) + 2 * FONT_SIZE;

	    g.setFont(MATH_FONT);
	    fm = g.getFontMetrics();

	    for (int i = 0; i < 3; i++) {
		Color c = Color.black;
		switch (i) {
		case 0: c = Color.blue; token = "wff"; break;
		case 1: c = Color.red; token = currentFamily == EUCLID ? "point" : "set";
		    break;
		case 2: c = Color.magenta; token = "class"; break;
		case 3: c = DARK_GREEN; token = "digit"; break;
		}
		g.setColor(c); g.drawString(token, currentX, currentY);
		currentX += fm.stringWidth(token) + 2 * FONT_SIZE;
		// Only show wff color for propositional families
		if (currentFamily != PRED_CALC && currentFamily != PRED_DEFS
		    && currentFamily != SET_THEORY && currentFamily != SET_DEFS
		    && currentFamily != EUCLID && i == 0) break;
		// Show classes only for set theory definitions
		if (currentFamily != SET_DEFS && i == 1) break;
	    }

	    // Display stack (or requested axiom in info mode)
	    String axOrTh = "axiom";
	    if (currentState.assertVec.size() != 0 || axiomInfoModeFlag) {
		currentY += Y_INCREMENT * 3 / 2;
		g.setFont(new Font("Dialog", Font.PLAIN, FONT_SIZE));
		g.setColor(Color.black);
		if (axiomInfoModeFlag) {
		    if (!axiomArr[infoModeAxiomToShow].proof.equals("")) axOrTh = "theorem";
		    g.setFont(new Font("Dialog", Font.BOLD, FONT_SIZE));
		    token = "Information for " + axOrTh + " " + axiomArr[infoModeAxiomToShow];
		    g.drawString(token, X_INIT, currentY); currentY += Y_INCREMENT;
		    g.setFont(new Font("Dialog", Font.PLAIN, FONT_SIZE));
		    token = "Description:  " + axiomArr[infoModeAxiomToShow].description;
		    g.drawString(token, X_INIT, currentY);
		    if (!axiomArr[infoModeAxiomToShow].proof.equals("")) {
			currentY += Y_INCREMENT;
			token = "Proof:  " + axiomArr[infoModeAxiomToShow].proof;
			g.drawString(token, X_INIT, currentY);
		    }
		    currentY += Y_INCREMENT * 3 / 2;
		    token = "Assertion made by this " + axOrTh + ":";
		} else {
		    if (currentState.hypVec.isEmpty()) {
			token =
			    "Assertion stack (each line is a theorem scheme of this logic family):";
		    } else {
			token =
			    "Assertion stack (each line is an inference from the hypotheses):";
		    }
		}
		g.drawString(token, X_INIT, currentY);
		g.setFont(MATH_FONT);
		VariableName.init(); // Initialize name map so var's will be renumbered
		if (axiomInfoModeFlag) {
		    currentY += Y_INCREMENT;
		    DrawSymbols.drawFormula(g, currentY,
					    axiomArr[infoModeAxiomToShow].assertion);
		} else {
		    // Display from top of stack down
		    for (int i = currentState.assertVec.size() - 1; i >= 0; i--) {
			currentY += Y_INCREMENT;
			DrawSymbols.drawFormula(g, currentY,
						currentState.assertVec.get(i));
		    }
		}
	    }

	    // Display hypotheses
	    if ((!axiomInfoModeFlag && currentState.hypVec.size() != 0) ||
		(axiomInfoModeFlag
		 && axiomArr[infoModeAxiomToShow].axHypVec.size() != 0)) {
		currentY += Y_INCREMENT * 3 / 2;
		g.setFont(new Font("Dialog", Font.PLAIN, FONT_SIZE));
		g.setColor(Color.black);
		if (axiomInfoModeFlag) {
		    token = "Hypotheses for this " + axOrTh + ":"; // in reverse order
		} else {
		    token =
			"Hypotheses for the assertions in the stack:"; // in reverse order
		}
		g.drawString(token, X_INIT, currentY);
		g.setFont(MATH_FONT);
		if (axiomInfoModeFlag) {
		    for (int i =
			     axiomArr[infoModeAxiomToShow].axHypVec.size() - 1;
			 i >= 0; i--) {
			currentY += Y_INCREMENT;
			DrawSymbols.drawFormula(g, currentY,
						axiomArr[infoModeAxiomToShow].axHypVec.get(i));
		    }
		} else {
		    for (int i = currentState.hypVec.size() - 1; i >= 0; i--) {
			currentY += Y_INCREMENT;
			DrawSymbols.drawFormula(g, currentY, currentState.hypVec.get(i));
		    }
		}
	    }

	    // Display distinct variable pairs
	    if ((!axiomInfoModeFlag && !currentState.dVarVec.isEmpty()) ||
		(axiomInfoModeFlag && !axiomArr[infoModeAxiomToShow].axDVarVec.isEmpty())) {
		currentY += Y_INCREMENT + Y_INCREMENT / 2;
		g.setFont(new Font("Dialog", Font.PLAIN, FONT_SIZE));
		g.setColor(Color.black);
		g.drawString(
			     "Substitutions for these variable pairs may not have variables in",
			     X_INIT, currentY);
		currentY += Y_INCREMENT;
		if (axiomInfoModeFlag) {
		    token = "common for an instance of the " + axOrTh +
			" to remain valid:";
		} else {
		    token = "common for the assertions to remain valid:";
		}
		g.drawString(token, X_INIT, currentY);
		g.setFont(MATH_FONT);
		currentY += Y_INCREMENT;

		ArrayList<String> dVarVec = axiomInfoModeFlag ? axiomArr[infoModeAxiomToShow].axDVarVec : currentState.dVarVec;
		currentY = DrawSymbols.drawDistinct(g, currentY, dVarVec);
	    }
	} // paint

    } // class mm

// Formula drawing
final class DrawSymbols {

    static Graphics g;
    static int currentX; static int currentY;
    static FontMetrics fm;
    static short lastTokenType;

    // Box coordinates for special characters
    static int leftX;
    static int rightX;
    static int bottomY;
    static int topY;
    static int middleX;
    static int middleY;
    static int one4thX;
    static int three4thX;
    static int one4thY;
    static int three4thY;

    private static final void setBox(int width) {
	leftX = currentX;
	rightX = currentX + width;
	bottomY = currentY;
	topY = currentY - fm.getHeight() * 2 / 3;
	middleX = (leftX + rightX) / 2;
	middleY = (bottomY + topY) / 2;
	one4thX = (leftX + middleX) / 2;
	three4thX = (middleX + rightX) / 2;
	one4thY = (bottomY + middleY) / 2;
	three4thY = (middleY + topY) / 2;
    }

    private static final void drawToken(String token, short type) {
	Color c = Color.black; // -1 = connective
	if (type == (short)(-1)) {
	    // Connective
	    g.setColor(c);
	    // Compose special tokens
	    if (token.equals("A.")) { // forall
		setBox(fm.stringWidth("M"));
		g.drawLine(leftX, topY, middleX, bottomY);
		g.drawLine(middleX, bottomY, rightX, topY);
		g.drawLine(one4thX, middleY, three4thX, middleY);
	    } else if (token.equals("->")) { // arrow
		setBox(fm.stringWidth("M") * 2);
		g.drawLine(leftX, middleY, rightX, middleY);
		g.drawLine(middleX, topY, rightX, middleY);
		g.drawLine(middleX, bottomY, rightX, middleY);
	    } else if (token.equals("<->")) { // double arrow
		setBox(fm.stringWidth("M") * 3);
		g.drawLine(leftX, middleY, rightX, middleY);
		g.drawLine(one4thX, topY, leftX, middleY);
		g.drawLine(one4thX, bottomY, leftX, middleY);
		g.drawLine(three4thX, topY, rightX, middleY);
		g.drawLine(three4thX, bottomY, rightX, middleY);
	    } else if (token.equals("\\/")) { // vee
		setBox(fm.stringWidth("M"));
		g.drawLine(leftX, three4thY, middleX, bottomY);
		g.drawLine(rightX, three4thY, middleX, bottomY);
	    } else if (token.equals("/\\")) { // wedge
		setBox(fm.stringWidth("M"));
		g.drawLine(leftX, bottomY, middleX, three4thY);
		g.drawLine(rightX, bottomY, middleX, three4thY);
	    } else if (token.equals("E.")) { // exists
		setBox(fm.stringWidth("M"));
		g.drawLine(leftX, bottomY, rightX, bottomY);
		g.drawLine(leftX, middleY, rightX, middleY);
		g.drawLine(leftX, topY, rightX, topY);
		g.drawLine(rightX, topY, rightX, bottomY);
	    } else if (token.equals("-.")) { // not
		setBox(fm.stringWidth("M"));
		g.drawLine(leftX, middleY, rightX, middleY);
		g.drawLine(rightX, middleY, rightX, bottomY);
	    } else if (token.equals("e.")) { // epsilon
		setBox(fm.stringWidth("M"));
		g.drawLine(leftX, middleY, middleX, topY);
		g.drawLine(middleX, topY, rightX, topY);
		g.drawLine(leftX, middleY, middleX, bottomY);
		g.drawLine(middleX, bottomY, rightX, bottomY);
		g.drawLine(leftX, middleY, three4thX, middleY);
	    } else if (token.equals("u.")) { // union
		setBox(fm.stringWidth("M"));
		g.drawLine(leftX, three4thY, leftX, one4thY);
		g.drawLine(leftX, one4thY, middleX, bottomY);
		g.drawLine(middleX, bottomY, rightX, one4thY);
		g.drawLine(rightX, one4thY, rightX, three4thY);
	    } else if (token.equals("i^i")) { // intersection
		setBox(fm.stringWidth("M"));
		g.drawLine(leftX, bottomY, leftX, middleY);
		g.drawLine(leftX, middleY, middleX, three4thY);
		g.drawLine(middleX, three4thY, rightX, middleY);
		g.drawLine(rightX, middleY, rightX, bottomY);
	    } else if (token.equals("U.")) { // Union
		setBox(fm.stringWidth("M"));
		g.drawLine(leftX, topY, leftX, one4thY);
		g.drawLine(leftX, one4thY, middleX, bottomY);
		g.drawLine(middleX, bottomY, rightX, one4thY);
		g.drawLine(rightX, one4thY, rightX, topY);
	    } else if (token.equals("|^|")) { // Intersection
		setBox(fm.stringWidth("M"));
		g.drawLine(leftX, bottomY, leftX, three4thY);
		g.drawLine(leftX, three4thY, middleX, topY);
		g.drawLine(middleX, topY, rightX, three4thY);
		g.drawLine(rightX, three4thY, rightX, bottomY);
	    } else if (token.equals("(_")) { // subset
		setBox(fm.stringWidth("M"));
		g.drawLine(rightX, topY, leftX, topY);
		g.drawLine(leftX, topY, leftX, one4thY);
		g.drawLine(leftX, one4thY, rightX, one4thY);
		g.drawLine(leftX, bottomY, rightX, bottomY);
	    } else if (token.equals("(/)")) { // empty set
		setBox(fm.stringWidth("M"));
		g.drawOval(leftX, topY, rightX - leftX, bottomY - topY);
		g.drawLine(leftX, bottomY, rightX, topY);
	    } else if (token.equals("[]")) { // box
		setBox(fm.stringWidth("M"));
		g.drawRect(leftX, topY, rightX - leftX, bottomY - topY);
	    } else if (token.equals("<>")) { // diamond
		setBox(fm.stringWidth("M"));
		g.drawLine(leftX, middleY, middleX, topY);
		g.drawLine(middleX, topY, rightX, middleY);
		g.drawLine(rightX, middleY, middleX, bottomY);
		g.drawLine(middleX, bottomY, leftX, middleY);
	    } else if (token.equals("_|_")) { // upside-down T (false)
		setBox(fm.stringWidth("M"));
		g.drawLine(leftX, bottomY, rightX, bottomY);
		g.drawLine(middleX, bottomY, middleX, topY);
	    } else { // Output as is
		g.drawString(token, currentX, currentY);
		rightX = currentX + fm.stringWidth(token);
	    }
	    currentX = rightX + 1;
	} else {
	    // Variable
	    switch (type) {
	    case 0: c = Color.blue; break; // wff
	    case 1: c = Color.red; break; // set (var)
	    case 2: c = Color.magenta; break; // class
	    case 3: c = mm.DARK_GREEN; break; // digit
	    }
	    g.setColor(c);

	    // Put extra space between two variables for better appearance
	    if (lastTokenType >= 0) currentX += mm.WHITE_SPACE / 2;
	    g.drawString(token, currentX, currentY);
	    currentX += fm.stringWidth(token);

	}

	lastTokenType = type;

	currentX += mm.WHITE_SPACE;

    }


    static final void drawFormula(Graphics wg, int wcurrentY, String formula) {
	String token;
	int position0;
	int position;
	short varNum;
	short varType;
	int p2;

	lastTokenType = (short)(-1); /* Init */

	g = wg;
	fm = g.getFontMetrics();
	currentY = wcurrentY;
	currentX = mm.X_INIT;
	formula = PrimFormula.getDisplay(formula, true); // true returns variables
	//   as $var:type

	formula = formula + " ";
	position0 = 0;
	position = formula.indexOf(' ');
	while (position != -1) {
	    token = formula.substring(position0, position);
	    if (token.charAt(0) == '$') { // Variable
		p2 = token.indexOf(':');
		varNum = (short)Integer.parseInt(token.substring(1, p2));
		varType = (short)Integer.parseInt(token.substring(p2 + 1));
		drawToken(VariableName.name(varNum, varType), varType);
	    } else { // Connective
		drawToken(token, (short)(-1));
	    }
	    position0 = position + 1;
	    position = formula.indexOf(' ', position0);
	}
    }

    // Draw the distinct variable pair list
    // Returns the new currentY
    static final int drawDistinct(Graphics wg, int wcurrentY,
				  ArrayList<String> distinctVarVec) {
	short v;

	lastTokenType = (short)(-1); /* Init */

	g = wg;
	fm = g.getFontMetrics();
	currentY = wcurrentY;
	currentX = mm.X_INIT;

	for (int i = 0; i < distinctVarVec.size(); i++) {
	    for (int j = 0; j < 2; j++) {
		v = (short)(distinctVarVec.get(i).charAt(j));
		// We assume type is already assigned, so 0 is OK */
		drawToken(VariableName.name(v, (short)0), VariableName.type(v));
		currentX += 4;
	    }
	    currentX += 20;
	    // New line every 10 pairs
	    if ((i + 1) % 10 == 0) {
		currentX = mm.X_INIT;
		currentY += mm.Y_INCREMENT;
	    }
	}
	return currentY;
    }


} // class DrawSymbols

// Primitive formula handler
final class PrimFormula {

    // Get shortest primitive formula
    static final String pformula(String formula, int start) {
	String subformula;
	int position;
	short connNum;
	int i;
	if ((short)(formula.charAt(start)) > 0) {
	    // It's a variable
	    return formula.substring(start, start + 1);
	} else {
	    // It's a connective
	    connNum = (short)(formula.charAt(start));
	    connNum = (short)(- (connNum + 1));
	    subformula = formula.substring(start, start + 1);
	    position = start;
	    for (i = 0; i < mm.connectiveArr[connNum].argtypes.length; i++) {
		position = start + subformula.length();
		subformula = subformula + pformula(formula, position);
	    }
	    return subformula;
	}
    } // pformula

    // Return variable/connective types in a formula string
    static final String getTypes(String formula, int start) {
	String typesList;
	int position;
	short connNum;
	short typeNum;
	int i;
	if ((short)(formula.charAt(start)) > 0) {
	    // It's a variable; we don't know the type yet; default to wff
	    return String.valueOf((char)0);
	} else {
	    // It's a connective
	    connNum = (short)(formula.charAt(start));
	    connNum = (short)(- (connNum + 1));
	    typeNum = mm.connectiveArr[connNum].type;
	    typesList = String.valueOf((char)typeNum);
	    position = start;
	    for (i = 0; i < mm.connectiveArr[connNum].argtypes.length; i++) {
		position = start + typesList.length();
		typeNum = mm.connectiveArr[connNum].argtypes[i];
		// Override the type of the first return char (could be
		// a variable with type not yet known)
		typesList = typesList + String.valueOf((char)typeNum)
		    + (new String(getTypes(formula, position))).substring(1);
	    }
	    return typesList;
	}
    } // getTypes

    // Return formula in standard (display) notation
    // If raw, then each variable is in the form $n:m, where m is the type
    static String typesList;
    static final String getDisplay(String formula, boolean raw) {
	typesList = getTypes(formula, 0);
	return subGetDisplay(formula, 0, raw);
    }
    static final String getDisplay(String formula) { return getDisplay(formula, false); }

    static final String subGetDisplay(String formula, int start, boolean raw) {
	// String tokenSeparator = " "; // Separator character between tokens in axiom menu
	String tokenSeparator = ""; // Separator character between tokens in axiom menu
	String subformula;
	int position;
	short connNum;
	int i;
	String[] displayArgs;
	String displayFormula;
	String tmpNotation;
	String token;
	short argNum;
	int charPosition0;
	int charPosition;
	tokenSeparator = raw ? " " : "";
	if ((short)(formula.charAt(start)) > 0) {
	    // It's a variable
	    return raw ? 
		"$" + (int)formula.charAt(start) + ":" + (int)typesList.charAt(start)
		: VariableName.name((short)(formula.charAt(start)),
				    (short)typesList.charAt(start));
	} else {
	    // It's a connective
	    connNum = (short)(-(short)(formula.charAt(start))-1);
	    subformula = formula.substring(start, start + 1);
	    position = start;
	    displayArgs = new String[mm.connectiveArr[connNum].argtypes.length];
	    // Collect the arguments in display notation
	    for (i = 0; i < mm.connectiveArr[connNum].argtypes.length; i++) {
		position = start + subformula.length();
		subformula = subformula + pformula(formula, position);
		displayArgs[i] = subGetDisplay(formula, position, raw);
	    }
	    tmpNotation = mm.connectiveArr[connNum].notation + " ";
	    displayFormula = "";
	    // Replace the arguments in the connectives display notation
	    charPosition0 = 0;
	    charPosition = tmpNotation.indexOf(' ');
	    while (charPosition != -1) {
		token = tmpNotation.substring(charPosition0, charPosition);
		if (token.charAt(0) == '$') { // Display template argument
		    argNum = (short)Integer.parseInt(token.substring(1));
		    if (displayFormula.length() == 0) {
			displayFormula = displayArgs[argNum - 1];
		    } else {
			displayFormula += tokenSeparator + displayArgs[argNum - 1];
		    }
		} else { // Display connective - output as is
		    if (displayFormula.length() == 0) {
			displayFormula = token;
		    } else {
			displayFormula = displayFormula + tokenSeparator + token;
		    }
		}
		charPosition0 = charPosition + 1;
		charPosition = tmpNotation.indexOf(' ', charPosition0);
	    }
	    return displayFormula;
	}
    } // subGetDisplay

} // class PrimFormula

// Get name for display of variable
final class VariableName {
    static ArrayList<String> varNameVec = new ArrayList<String>();
    static ArrayList<Integer> varTypeVec = new ArrayList<Integer>();
    static int[] varSoFar = new int[4]; // Counter for how many so far for
    // each type

    // Initialize (e.g. after renormalizing variables)
    final static void init() {
	varNameVec = new ArrayList<String>();
	varTypeVec = new ArrayList<Integer>();
	varSoFar = new int[4]; // Initialized to 0; there are 4 types
    }

    // Get name of variable - type must be 0 thru 3 (wff thru digit)
    final static String name(int var, short type) {
	int v;
	int quotient;
	int remainder;
	String suffix;
	// wff, var, class, digit
	String[] letters = {"PQRSTUWXYZ", "xyzwvutsrqpnmlkjihgfdcba",
			    "ABCDFGHJKLMN", "e"};
	if (var >= varNameVec.size()) { // extend to accomodate variable
	    varNameVec.ensureCapacity(var + 1);
	    varTypeVec.ensureCapacity(var + 1);
	}
	if(varNameVec.size()<=var || varNameVec.get(var)==null) { // hasn't been assigned yet
	    while(varNameVec.size()<=var) {
    		varNameVec.add(null);
    		varTypeVec.add(null);
	    }
	    // Get name based on type and previous names
	    v = varSoFar[type];
	    varSoFar[type]++;
	    quotient = v / letters[type].length();
	    remainder = v % letters[type].length();
	    suffix = quotient==0 ? "" : Integer.toString(quotient - 1);
	    varNameVec.set(var,letters[type].substring(remainder,remainder+1)+suffix);
	    varTypeVec.set(var,(int)type);
	}
	return varNameVec.get((int)var);
    }

    // This is a handy way to find out variable's type, but should only
    // be used after getting the variable's name
    final static short type(short var) { return (short)(varTypeVec.get(var).intValue()); }

} // VariableDisplay

// Define a logical connective
class Connective {
    String label;
    short type;
    short[] argtypes;
    String notation;
    Connective(String label, String wtype, int numArgs, String notation) {
	this.label = label;
	this.type = getExprType(wtype);
	this.argtypes = new short[numArgs];
	this.notation = notation;
    }
    void setArgtype(int arg, String sarg) { argtypes[arg] = getExprType(sarg); }

    // Get expression type number for input string; return -1 if bad
    private static short getExprType(String stype) {
	String TYPE_LIST[] = {"wff", "var", "class", "digit"};
	for (int i = 0; i < TYPE_LIST.length; i++) {
	    if (TYPE_LIST[i].equals(stype)) return (short)i;
	}
	return (short)(-1);
    }

    public String toString() { return label; }
  
} // class Connective

// Define an axiom
// (Future:  make Axiom same class as State for uniformity & to simplify pgm?)
class Axiom {
    String label;
    String assertion;
    ArrayList<String> axHypVec;
    ArrayList<String> axDVarVec; // Each string always has length 2
    String proof; // when converted from currentState
    String description;
    String menuEntry; // String to put into menu when no unification is
    // needed (store instead of recompute to speed up menu build)
    Axiom(String label, String englRPN, String description) {
	// This is the constructor for built-in axioms
	this.label = label;
	this.assertion = englToNumStr(englRPN);
	this.axHypVec = new ArrayList<String>();
	this.axDVarVec = new ArrayList<String>();
	this.description = description;
	this.proof = ""; // no proof for axiom (user-added theorems have proofs)
	makeMenuEntry();
    }
    void addHyp(String hyp) { axHypVec.add(englToNumStr(hyp)); }
    void addDistinct(String dVarPair) {
	assert dVarPair.length()==2;
	axDVarVec.add(englToNumStr(dVarPair));
    }

    // This constructor converts the top of the assertion stack into a Axiom
    // (Future major revision:  make Axiom and State the same class for
    //  simplicity?)
    Axiom(State st) {
	// We have to make clones because state contents will be changing
	State stCopy = st.makeClone();

	// Remove all assertions except last
	ArrayList<String> trimmedAssertionVec = new ArrayList<String>();
	ArrayList<String> trimmedProofVec = new ArrayList<String>();
	trimmedAssertionVec.add(stCopy.assertVec.get(stCopy.assertVec.size()-1));
	trimmedProofVec.add(stCopy.proofVec.get(stCopy.proofVec.size()-1));
	stCopy.assertVec = trimmedAssertionVec;
	stCopy.proofVec = trimmedProofVec;
	stCopy.normalize(); // Trim distinct vars

	label = "user-" + String.valueOf(mm.userTheorems.size() + 1);
	assertion = stCopy.assertVec.get(stCopy.assertVec.size()-1);
	proof = stCopy.proofVec.get(stCopy.proofVec.size()-1);
	axHypVec = stCopy.hypVec;
	axDVarVec = stCopy.dVarVec;
	description = "Theorem added by user";
	makeMenuEntry();
    }

    private void makeMenuEntry() {
	// Make string for axiom menu when no unification required
	VariableName.init();  // Reset variable vs. variable name & type
	// for PrimFormula.getDisplay(..)
	menuEntry = String.valueOf(
				   1 - axHypVec.size()) // Amt stack increases
	    + " " + label + " "                         // Label
	    + PrimFormula.getDisplay(assertion);        // ASCII formula
    }

    // Convert RPN character, space-separated strings to RPN numeric strings
    // Connectives are negative, variables are positive
    private static final String englToNumStr(String englRPN) {
	String token;
	int position0;
	int position;
	short varNum;
	short connNum;
	int i;
	StringBuffer numRPNbuf = new StringBuffer();

	englRPN += " ";
	numRPNbuf.ensureCapacity(englRPN.length() / 2);
	position0 = 0;
	position = englRPN.indexOf(' ');
	while (position != -1) {
	    token = englRPN.substring(position0, position);
	    if (token.charAt(0) == '$') { // Variable
		varNum = (short)Integer.parseInt(token.substring(1));
		numRPNbuf.append(String.valueOf((char)varNum));
	    } else { // Connective
		i = mm.connectiveLabels.indexOf(" " + token + " ");
		if (i == -1) System.out.println("Bug: Unknown connective " + token);
		connNum = (short)(mm.connectiveLabelMap.charAt(i));
		numRPNbuf.append(String.valueOf((char)(-(connNum + 1))));
	    }
	    position0 = position + 1;
	    position = englRPN.indexOf(' ', position0);
	}
	return numRPNbuf.toString();
    } // englToNumStr

    public String toString() { return label; }
  
} // class Axiom


// Define the stack (state)
class State {
    short maxVar; /* Largest variable used */
    ArrayList<String> assertVec;
    ArrayList<String> proofVec; // Proof for each assertion
    ArrayList<String> hypVec;
    ArrayList<String> dVarVec; // each string always has length 2

    ArrayList<Axiom> userThVec; // copy of userTheorems; used for Undo
    int currentFam; // for Undo

    State() {  // Constructor
	maxVar = 0;
	assertVec = new ArrayList<String>();
	proofVec = new ArrayList<String>();
	hypVec = new ArrayList<String>();
	dVarVec = new ArrayList<String>();
	userThVec = mm.userTheorems;
	currentFam = mm.currentFamily;
    }
    State makeClone() {
	State c = new State();
	c.maxVar = maxVar;
	c.assertVec = new ArrayList<String>(assertVec);
	c.proofVec = new ArrayList<String>(proofVec);
	c.hypVec = new ArrayList<String>(hypVec);
	c.dVarVec = new ArrayList<String>(dVarVec);
	c.userThVec = new ArrayList<Axiom>(userThVec);
	return c;
    }
    String getAssertion(int position) {return assertVec.get(position);}
    String getStackTop() {return assertVec.get(assertVec.size()-1);}
    void pushAssertion(String assertion, String proof) {
	assertVec.add(assertion);
	proofVec.add(proof);
    }
    void removeAssertionAt(int position) {assertVec.remove(position);}
    String getHyp(int position) {return hypVec.get(position);}
    void addHyp() {hypVec.add(String.valueOf((char)(++maxVar)));}
    void removeHypAt(int position) {hypVec.remove(position);}

    void normalize() {
	// Renumber all variables; reduce maxVar if gaps were eliminated
	// Also, trim off any distinct pairs that aren't in assertion or hyp
	// (important, otherwise distinct var list will have garbage entries)
	// Note:  variables are numbered starting at 1, not 0.
	short newMax = 0;
	short[] varMap = new short[maxVar + 1];
	StringBuffer scanBuf;
	int i; int j; short c;
	// Scan assertions
	for (i = 0; i < assertVec.size(); i++) {
	    scanBuf = new StringBuffer(assertVec.get(i));
	    for (j = 0; j < scanBuf.length(); j++) {
		c = (short)(scanBuf.charAt(j));
		if (c < 0) continue; // not a variable
		if (varMap[c] == 0) {
		    // Add new variable
		    newMax++;
		    varMap[c] = newMax;
		}
		scanBuf.setCharAt(j, (char)(varMap[c]));
	    }
	    assertVec.set(i, scanBuf.toString());
	}
	// Scan hypotheses
	for (i = 0; i < hypVec.size(); i++) {
	    scanBuf = new StringBuffer(hypVec.get(i));
	    for (j = 0; j < scanBuf.length(); j++) {
		c = (short)(scanBuf.charAt(j));
		if (c < 0) continue; // not a variable
		if (varMap[c] == 0) {
		    // Add new variable
		    newMax++;
		    varMap[c] = newMax;
		}
		scanBuf.setCharAt(j, (char)(varMap[c]));
	    }
	    hypVec.set(i, scanBuf.toString());
	}
	// Scan distinct variable pairs
	boolean discardFlag;
	for (i = 0; i < dVarVec.size(); i++) {
	    scanBuf = new StringBuffer(dVarVec.get(i));
	    discardFlag = false;
	    for (j = 0; j < scanBuf.length(); j++) {
		c = (short)(scanBuf.charAt(j));
		if (varMap[c] == 0) {
		    // In the case of distinct variables, we want to throw away
		    // ones not yet mapped (i.e. in no assertion or hypothesis)
		    discardFlag = true;
		    break;
		}
		scanBuf.setCharAt(j, (char)(varMap[c]));
	    }
	    if (!discardFlag) {
		dVarVec.set(i, scanBuf.toString());
	    } else {
		dVarVec.remove(i);
		i--;
	    }
	}
	// Update maxVar
	maxVar = newMax;
	// Initialize variable name/type finder
	VariableName.init();
    }

    // Build a special version of a State containing all steps of the proof
    // instead of just the stack entries.  Also, each proofVec string in the
    // special State has <step# label,step-ref,step-ref,...> instead of an
    // axiom list.  Used to display detailed proof for the 'Proof Info'
    // option.
    final static State buildProofInfoState(State currentState) {
	// Add proof steps one by one with special unify() mode, keeping all steps
	// Get the axiom-list version of the proof of the top of the stack
	String proof = currentState.proofVec.get(currentState.proofVec.size()-1);
	State proofInfoState = new State();
	// Copy any hypotheses
	for (int i = 0; i < currentState.hypVec.size(); i++) {
	    proofInfoState.addHyp();
	}
	// Scan the axiom-list proof
	proof = proof + " ";
	int position0 = 0;
	int position = proof.indexOf(' ');
	String label;
	while (position != -1) {
	    label = proof.substring(position0, position);
	    if (label.charAt(0) == '$') { // Hypothesis $hypnn - future: make sure
		//   that $ is not allowed if user name accepted for user proofs
		int hypNum = Integer.parseInt(label.substring(4)) - 1;
		proofInfoState.pushAssertion(
					     proofInfoState.hypVec.get(hypNum),
					     // Special label for hypothesis step
					     String.valueOf(proofInfoState.assertVec.size() + 1) + " "
					     + label);
	    } else {
		// Find the axiom with this label
		// Linear seach -- future speedup?
		int i;
		for (i = 0; i < mm.axiomArr.length; i++) {
		    if (mm.axiomArr[i] == null) continue;
		    if (mm.axiomArr[i].label.equals(label)) break;
		}
		proofInfoState = Unification.unify(mm.axiomArr[i], proofInfoState,
						   true);  // true means unification will not delete popped hypotheses
	    }
	    position0 = position + 1;
	    position = proof.indexOf(' ', position0);
	} // end while position != -1

	// Sort the proof steps (they are not sorted in proofInfoState)
	int[] stepSortMap = new int[proofInfoState.assertVec.size()];
	for (int i = 0; i < stepSortMap.length; i++) {
	    String labl = proofInfoState.proofVec.get(i);
	    int stepNum = Integer.parseInt(labl.substring(0,
							  labl.indexOf(' '))) - 1;
	    stepSortMap[stepNum] = i;
	}
	ArrayList<String> sortedAssertionVec = new ArrayList<String>();
	ArrayList<String> sortedProofVec = new ArrayList<String>();
	for (int i = 0; i < stepSortMap.length; i++) {
	    int step = stepSortMap[i];
	    sortedAssertionVec.add(proofInfoState.assertVec.get(step));
	    sortedProofVec.add(proofInfoState.proofVec.get(step));
	}
	proofInfoState.assertVec = sortedAssertionVec;
	proofInfoState.proofVec = sortedProofVec;
	// end sort

	proofInfoState.normalize(); // Trim distinct vars, init var names
	// Dummy run thru steps in reverse order for desired variable name
	// assignment
	for (int i = proofInfoState.assertVec.size() - 1; i >=0; i--) {
	    PrimFormula.getDisplay(proofInfoState.assertVec.get(i));
	}
	return proofInfoState;
    } // buildProofInfoState

} // class State

// Define a substitution
class Substitution {
    short subVar;      // The variable being substituted
    String substString;  // What it's substituted with
    Substitution(short sV, String sS) {
	subVar = sV;
	substString = sS;
    }

    // Makes a substitution into a formula
    final static String makeSubst(String formula, Substitution subst) {
	int i;
	i = -1;
	while (true) {
	    i = formula.indexOf(subst.subVar, i + 1);
	    if (i < 0) break;
	    formula = formula.substring(0, i) + subst.substString
		+ formula.substring(i + 1);
	}
	return formula;
    }

    // Makes a set of substitutions into a formula
    final static String makeVecSubst(String formula, ArrayList substVec) {
	int i;
	for (i = 0; i < substVec.size(); i++) {
	    formula = makeSubst(formula, (Substitution)(substVec.get(i)));
	}
	return formula;
    }
} // class Substitution

// Define unification methods
final class Unification {

    // These variables are used by calling program
    static ArrayList<String> newDVarVec;
    static short oldMaxVar; // Original largest variable
    static short newMaxVar; // New largest variable
    static ArrayList<Substitution> substVec; // Substitution list to make throughout State

    // Local static variables
    static ArrayList<String> axiomHypVec = new ArrayList<String>();
    static ArrayList<String> stateHypVec = new ArrayList<String>();

    // Unification algorithm - returns a new State if unification
    // possible, null otherwise
    final static State unify(Axiom testAxiom, State currentState,
			     boolean proofInfoFlag) {
	int i; int hyp;
	short cr; short cs;
	short substVar; String substStr;
	Substitution subst;
	int currentStateStackSize; int axiomHypSize;
	State newState;
	String axiomHyp; String stateHyp;

	substVec = new ArrayList<Substitution>();
	currentStateStackSize = currentState.assertVec.size();
	if (testAxiom == null) return null; // To allow for sloppy axiom array
	axiomHypSize = testAxiom.axHypVec.size();

	// See if stack has enough entries
	if (currentStateStackSize < axiomHypSize) {
	    return null;
	}

	// Build state hypothesis ArrayList
	stateHypVec = new ArrayList<String>();
	for (hyp = 0; hyp < axiomHypSize; hyp++) {
	    stateHypVec.add(currentState.assertVec.get(
						       currentStateStackSize - axiomHypSize + hyp));
	}

	// Don't destroy caller's dVarVec
	newDVarVec = new ArrayList<String>(currentState.dVarVec);

	oldMaxVar = currentState.maxVar;
	newMaxVar = currentState.maxVar;

	// Build axiom hypothesis ArrayList with renumbered variables
	axiomHypVec = new ArrayList<String>();
	for (hyp = 0; hyp < axiomHypSize; hyp++) {
	    axiomHypVec.add(renumberVars(testAxiom.axHypVec.get(hyp)));
	}
	// Renumber distinct variables of axiom and add to dist var ArrayList
	for (i = 0; i < testAxiom.axDVarVec.size(); i++) {
	    newDVarVec.add(renumberVars(testAxiom.axDVarVec.get(i)));
	}

	// Unify each hypothesis
	for (hyp = 0; hyp < axiomHypSize; hyp++) {
	    i = -1;
	    while (true) {
		i++;
		// Assign working hypotheses strings; also reassign them each
		// pass thru loop to reflect result of substitution at end of loop
		axiomHyp = axiomHypVec.get(hyp);
		stateHyp = stateHypVec.get(hyp);
		if (i >= axiomHyp.length() || i >= stateHyp.length()) {
		    break;
		}
		cr = (short)(axiomHyp.charAt(i));
		cs = (short)(stateHyp.charAt(i));
		if (cr == cs) continue;
		if (cr > 0) { // Variable in axiom
		    substStr = PrimFormula.pformula(stateHyp, i); // Get subformula
		    substVar = cr;
		} else {
		    if (cs > 0) { // Variable in state hyp
			substStr = PrimFormula.pformula(axiomHyp, i); // Get subformula
			substVar = cs;
		    } else {
			return null; // Unif not possible - connectives mismatch
		    }
		}
		if (substStr.indexOf((char)substVar) >= 0) {
		    return null; // Unif not possible - substituted var in substitution
		}
		subst = new Substitution(substVar, substStr);
		if (!rebuildDistinct(subst)) {
		    return null; // Dist var violation
		}
		makeSub(subst); // Make subst to hyp's and substVec
		substVec.add(subst);
	    }
	    if (axiomHyp.length() != stateHyp.length()) {
		return null; // Unif not possible
	    }
	}

	// Build new State to return to caller
	newState = new State();
	// Build new assertion stack
	newState.assertVec = new ArrayList<String>();

	if (proofInfoFlag) {
	    // Don't discard used-up assertions in this mode, but put them
	    // at the bottom of the stack so they'll be available for the detailed
	    // proof
	    for (i = currentStateStackSize - axiomHypSize; i < currentStateStackSize;
		 i++) {
		newState.pushAssertion(Substitution.makeVecSubst(
								 currentState.assertVec.get(i), substVec),
				       currentState.proofVec.get(i));
	    }
	}

	// Copy assertions and their proofs that were not popped by unification
	for (i = 0; i < currentStateStackSize - axiomHypSize; i++) {
	    newState.pushAssertion(Substitution.makeVecSubst(
							     currentState.assertVec.get(i), substVec),
				   currentState.proofVec.get(i));
	}
	// Build proof for new assertion
	String newProof = testAxiom.label;
	if (proofInfoFlag) {
	    // Format is step#, axiom used, steps used by hypotheses of axiom
	    newProof = String.valueOf(currentStateStackSize + 1) + " " + newProof;
	    for (i = currentStateStackSize - 1;
		 i >= currentStateStackSize - axiomHypSize; i--) {	
		newProof = newProof + "," +
		    currentState.proofVec.get(i).substring(0,
							   currentState.proofVec.get(i).indexOf(' '));
	    }
	} else {
	    // Format is axiom used, preceded by concatenated proofs of hypotheses
	    for (i = currentStateStackSize - 1;
		 i >= currentStateStackSize - axiomHypSize; i--) {
		newProof = currentState.proofVec.get(i) + " " + newProof;
	    }
	}
	// Push new, substituted assertion and proof from result of axiom
	newState.pushAssertion(
			       Substitution.makeVecSubst(renumberVars(testAxiom.assertion), substVec),
			       newProof);
	// Copy hypotheses with substitutions made to them
	for (i = 0; i < currentState.hypVec.size(); i++) {
	    newState.hypVec.add(Substitution.makeVecSubst(
							  currentState.hypVec.get(i), substVec));
	}
	// Assign distinct variable list
	newState.dVarVec = newDVarVec;
	// Assign largest variable
	newState.maxVar = newMaxVar;
	return newState;
    }

    // Renumber variables in a formula from a axiom, by adding axiom's var #
    // (which must be > 0) to oldMaxVar
    final static String renumberVars(String axiomFormula) {
	StringBuffer formulaBuf = new StringBuffer(axiomFormula);
	int i; short newVar;
	// Renumber variables
	for (i = 0; i < formulaBuf.length(); i++) {
	    if ((short)(formulaBuf.charAt(i)) > 0) {
		newVar = (short)(oldMaxVar + (short)(formulaBuf.charAt(i)));
		formulaBuf.setCharAt(i, (char)newVar);
		if (newVar > newMaxVar) newMaxVar = newVar;
	    }
	}
	return formulaBuf.toString();
    }


    // Make substitution to hyp's and substVec (substVec is theoretically
    // not necessary but done to speed things up)
    final static void makeSub(Substitution subst) {
	int hyp; int sub; 
	for (hyp = 0; hyp < stateHypVec.size(); hyp++) {
	    stateHypVec.set(hyp, Substitution.makeSubst(stateHypVec.get(hyp), subst));
	    axiomHypVec.set(hyp, Substitution.makeSubst(axiomHypVec.get(hyp), subst));
	}
	for (sub = 0; sub < substVec.size(); sub++) {
	    substVec.get(sub).substString =
		Substitution.makeSubst(substVec.get(sub).substString, subst);
	}
    }

    // Rebuild newDVarVec after a substitution
    // Returns true if no distinct variable violations, false if there were
    final static boolean rebuildDistinct(Substitution subst) {
	int ilimit = newDVarVec.size();
	int i; int j;
	boolean found = false;
	short v0; short v1;
	short vsub;
	String dpair;
	for (i = 0; i < ilimit; i++) {
	    v0 = (short)(newDVarVec.get(i).charAt(0));
	    v1 = (short)(newDVarVec.get(i).charAt(1));
	    if (v1 == subst.subVar) {
		short vtmp = v0;
		v0 = v1;
		v1 = vtmp;
	    }
	    if (v0 == subst.subVar) {
		// 1st var is substituted
		for (j = 0; j < (subst.substString).length(); j++) {
		    vsub = (short)((subst.substString).charAt(j));
		    if (vsub < 0) continue; // Not a variable
		    if (vsub == v1) {
			// Distinct variable conflict
			return false;
		    }
		    // Spawn off a new pair
		    dpair = String.valueOf((char)vsub) + String.valueOf((char)v1);
		    newDVarVec.add(dpair);
		}
		// Remove substituted pair
		newDVarVec.remove(i);
		// And lower limits
		i--; ilimit--;
		found = true;
	    }
	}
	if (found) { // If a substitution was made, clean up the list
	    // Put variables in ascending order in each pair
	    for (i = 0; i < newDVarVec.size(); i++) {
		v0 = (short)(newDVarVec.get(i).charAt(0));
		v1 = (short)(newDVarVec.get(i).charAt(1));
		if (v0 > v1) {
		    dpair = String.valueOf((char)v1) + String.valueOf((char)v0);
		    newDVarVec.set(i, dpair);
		}
	    }
	    // Sort the list
	    Collections.sort(newDVarVec);
	    // Remove duplicates
	    for (i = ilimit - 1; i > 0; i--) {
		if (newDVarVec.get(i).equals(newDVarVec.get(i-1))) {
		    // Remove one of them
		    newDVarVec.remove(i);
		}
	    }
	}
	return true;
    } // rebuildDistinct
}
