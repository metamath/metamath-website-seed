$( UT9002.mm $)
  $c ( $. 
  $c ) $. 
  $c -> $.
  $c wff $.
  $c |- $. 
  $v ph $.
  $v ps $.
  $v ch $.
  wph $f wff ph $.
  wps $f wff ps $.
  wch $f wff ch $.
  wi $a wff ( ph -> ps ) $.
  ax-1 $a |- ( ph -> ( ps -> ph ) ) $.
  ax-2 $a |- ( ( ph -> ( ps -> ch ) ) 
             -> ( ( ph -> ps ) -> ( ph -> ch ) ) ) $.
  ${
    min $e |- ph $.
    maj $e |- ( ph -> ps ) $.
    ax-mp $a |- ps $.
  $}
  ${
    a1i.1 $e |- ph $.
    a1i $p |- ( ps -> ph ) $=
      ( wi ax-1 ax-mp ) ABADCABEF $.
  $}
  ${
    a2i.1 $e |- ( ph -> ( ps -> ch ) ) $.
    a2i $p |- ( ( ph -> ps ) -> ( ph -> ch ) ) $=
      ( wi ax-2 ax-mp ) ABCEEABEACEEDABCFG $.
  $}
