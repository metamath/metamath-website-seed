 $( $t
  htmldef "mychar" as "mychareplacement" x;
 $)
 
