 $( $t
  htmldef "mychar""" as "mychar""eplacement"; 
  
  htmldef "mychar""""" as "mychar""""eplacement"; 

 $)
 
