${
    $d x y z $.
    ax-1 $a |- ( x , y , z ) $.
$}

