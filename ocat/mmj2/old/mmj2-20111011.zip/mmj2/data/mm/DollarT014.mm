 $( $t
  htmldef "mychar" as ""; 
 $)
 
