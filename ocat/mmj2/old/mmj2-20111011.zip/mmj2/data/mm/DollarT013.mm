 $( $t
  htmldef "" as "mychareplacement";
 $)
 
