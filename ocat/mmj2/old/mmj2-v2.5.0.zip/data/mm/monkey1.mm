$( monkey1.mm $) 

  $c ( AND ) $. 
  $c monkey SpeakNoEvil HearNoEvil SeeNoEvil $.
  $c ARE IN THE Barrel $.

  thingsinthecontainer   $a ( SpeakNoEvil AND HearNoEvil AND SeeNoEvil )
                              ARE IN THE Barrel
                         $.

  3BadMonkeysInTheBarrel $p ( SpeakNoEvil AND HearNoEvil AND SeeNoEvil )
                              ARE IN THE Barrel
       $=
            thingsinthecontainer
       $. 
  
