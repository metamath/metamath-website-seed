  ${
    UT4001.1 $e    |- A e. V
             $.
    UT4001   $p    |- { x |
                        ( x (_ A /\
                          ( E. n e. om ( A \ x ) ~~ n \/
                            x = (/) ) ) } e.
                      Top
             $= ? $.
  $} 

  ${
    UT4002.1 $e    |- D =
                      { <. <. x ,
                              y >. ,
                              z >. |
                              ( ( x e. CC /\ y e. CC ) /\
                                z = ( abs ` ( x - y ) ) ) }
             $.
    UT4002   $p    |- <. CC , D >. e. Met
             $= ? $.
  $}

  ${
    UT4003.1 $e |- ph $.
    UT4003   $p |- ( ps -> ph )
             $= wph wps ax-mp $.
  $}
