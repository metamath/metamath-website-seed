$( testing mmj2 pa disjoint var 
   soft/hard errors in unification search $)

$c wff |- e ( , ) $.
$v x y z w v u v1 v2 v3 v4 v5 v6 v7 v8 v9 v10 v11 $.

wx $f wff x $. wy $f wff y $. wz $f wff z $. ww $f wff w $.
wv $f wff v $. wu $f wff u $. wv1 $f wff v1 $. wv2 $f wff v2 $.
wv3 $f wff v3 $. wv4 $f wff v4 $. wv5 $f wff v5 $. wv6 $f wff v6 $.
wv7 $f wff v7 $. wv8 $f wff v8 $. wv9 $f wff v9 $. wv10 $f wff v10 $.
wv11 $f wff v11 $.

wi $a wff ( x , y , z ) $.

 