$( E-IO-0013 Token after label not a keyword ($*), label = $)
label NonCommentToken 

$( E-IO-0014 Label input for keyword that should not
             have one (only $e, $f, $a, $p have labels) $)
a $c a $.

$( E-IO-0015 Comment contains embedded .......) character string, 
             token = $)
$( $( $)

$( E-IO-0016 Include File Name contains $ or other invalid"
             characters: $)
$[ my$file.txt $]
             
$( E-IO-0017 Include statement ($[ x.mm $]) incomplete
             premature end of file! $)
$[ myfile.txt
