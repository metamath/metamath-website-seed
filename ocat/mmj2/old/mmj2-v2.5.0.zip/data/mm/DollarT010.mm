 $( $t
  htmldef "mychar" as "mychareplacement";
  htmldef "mychar" as "mychareplacement";
 $)
 
