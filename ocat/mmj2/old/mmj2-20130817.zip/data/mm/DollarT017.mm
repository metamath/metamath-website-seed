 $( $t
  htmldef "mychar" as "" + "mych
ar"
  + "eplacement"; 
 $)
 
