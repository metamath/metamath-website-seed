=========================================================
6-Sep-2012

TESTmmj2jar.zip:

Unzip and double-click on mmj2.bat.

- If you like, in Windows, manually create a
desktop shortcut to mmj2.bat for convenience.

- In OSX or Linux just plop the
TESTmmj2jar\mmj2.jar into your regular
environment, temporarily of course, haha...

Future test versions will be named the same and I
will re-upload new versions of TESTmmj2jar.zip
whenever.

* * *

About It --> TESTmmj2jar.zip

This is simply the test environment mmj2\mmj2jar
directory with no updates other than the new
code.

This is a VERY notable version of the Search
Enhancment: it delivers a 'system' that is merely
missing several features:

Missing Features:

* 'New:' button
* Search Data fields (all)
* Extended Search (all)
* ExclLabels:
* MaxTime:
* AutoSelect:

WARNING: the code is largely untested. It almost
certainly has bugs, perhaps dramatic bugs :-)
The purpose of releashing this thing now is just
to let you play with it and see how it looks.

NOTE: The new Search menu on the ProofAsstGUI
navigates you to the new Search windows. Meanwhile,
the right-mouse button popup menu contains the new
'Search Options', 'Step Search' and 'General Search'
options -- in addition to the old 'Step Selector'.
Double-clicking a derivation proof step takes you
to the old, Step Selector.

What this boils down to is that you can compare
the new Search Results to the old Step Selector
Dialog search results -- and the new Search lets you
do everything the old, Step Selector does, including
'Apply'ing a search result to update the originally
designated derivation step for unification!

CHANGE MADE: The 'Print' button was removed from the
Search Options and Search Results windows. Instead,
print functionality was rolled-into the 'Stats' option,
which is now an integer from 0 thru 999. Choose level
4 or higher and the Search Results are printed.

P.S. For now, 'Stats' just print to the command prompt
window.