http://us2.metamath.org:88/ocat/mmj2/TESTmmj2jar.zip



=========================================================
20-Sep-2012

Just a quick fix to the ParseExpr search: if your ForWhat
search term is not just a variable then parse sub-trees
consisting of just a variable hypothesis are excluded
from the search -- though a search term which is just
a variable will match parse sub-trees consisting of
just variable hypotheses.

=========================================================
19-Sep-2012

Once again, for expediency I am just prepending this
README.txt to the prior version. Cumulative.

In this new test version of the mmj2 Search Enhancement,
the 'ParseExpr' and 'ParseStmt' Format types are
enabled in the Search Data portion of the Search Options
window!

HOWEVER...I disallowed using Work Variables in ParseExpr
and ParseStmt. Reason: reduce complexity, not just in the
code but in the definitions of things like Oper '>' with
Format 'ParseExpr'. There is also a huge amount of overhead
running Work Variables -- and note that your Step Search
does allow Work Variables in the derivation proof step
AND its hypotheses, so with some ingenuity you can still
do searches involving Work Variables.

Anyway, back to ParseExpr and ParseStmt...

These are powerful search formats. Matching is based
on successful unification of the ForWhat field search term(s)
expression or statement with assertions. The Oper choice
determines which statement/expression is the target:
'<' and '<=' mean the database is the unification target and
'>' and '>=' mean that the ForWhat search term is the target.

With 'ParseStmt' you don't need to enter '|-' in ForWhat,
the system knows to use the current Provable Logic Statement
Type Code. With 'ParseExpr' mmj2 first atttempts syntactic
parsing using '|-' and then the set of syntax axiom type
codes, if necessary.

The 'Oper' field has an entire set of relational operators
specifically for use with ParseExpr and ParseStmt: <=, <, =,
==, >=, > and <>. Refer to Search Options Help, "Oper" field,
for definitions (this will exercise your brain...)

CAUTION: The InWhat field now defaults to '$ap', meaning that
the search target is the set of axiom and provable statements.
If you want to search in the logical hypothesis statements
associated with each assertion you need to include the 'e'
in InWhat -- for example, '$aep'. I mention this because
evaluating the search results of ParseExpr and ParseStmt
can be confusing and the 'problem' may be your choice of InWhat.


The following Search Options window fields are inoperative:

- Search Controls:

     - Extended Search: all

     - AutoSelect.



=========================================================
13-Sep-2012

Once again, I am just prepending this README.txt to prior
version. It is brief:

1) I added code to implement the Search Data area of
the Search Options window -- except for the ParseExpr
and ParseStmt Format types. Note that entering Search
Data is optional and you can 'Search' using just the
Search Options window Exclusion Criteria, plus of
course, Step Search mode unifications.

One new quirk: all Comment searches are case insensitive.
Internally mmj2 converts assertion Comment data to lower
case and then automatically converts the user's search terms.
However, with Format 'RegExpr' you need to explicitly
search comments using lower-case.

Also, in a minor spec change: Format types Metamath, RegExpr
and CharStr operate on strings, not Metamath token. The
strings are 'normalized' by inserting a blank (' ') between
each two non-whitespace tokens and discarding the original
whitespace tokens. (And, as mentioned already, Comments
are converted to lower-case internally.)

BE AWARE: The 4 Search Data lines are evaluated top to
bottom, with evaluation halting as soon as truth or
falsity of the set of 4 Search Data lines can be
determined. Likewise, multiple search terms in a single
ForWhat fields on a Search Data line are evaluated
left-to-right using either the implicit 'AND' operator
or the (optional) explicity 'OR' operator. Also, if
InWhat is set to $ae on one line and $ep on another line,
if the two lines are connected with 'AND', then no
search results will be generated!

Not much testing has been done. Beware :-)


2) Still not yet coded:

- Search Data Format types ParseExpr and ParseStmt
- Extended Search fields (all),
- AutoSelect.



=========================================================
9-Sep-2012

I am just prepending this README.txt to the 6-Sep version
as there are only a few changes -- but they are pretty big.

1) Search Options MaxTime and ExclLabels are now operational!
It turned out that MaxTime required only a dozen lines of
code and ExclLabels was easy enough to code using Regular
Expressions to convert the Metamath search label specifiers
into Regular Expressions!

This leaves only the following Search Options fields inoperative:

- Search Data: all

- Search Controls:

     - Extended Search: all

     - AutoSelect.


2) Search Option 'Stats' now generates output to the
Request Messages window. This is an existing Proof Assistant
window that has historically been forgotten, partly because
it tends to hide behind the ProofAsstGUI frame. Now it
demonstrates its utility as a place to dump large amounts
of data resulting from search requests! (Stats data will be
available in RunParm command output as well -- just not yet.)

I enclosed a file, ScreenDump20120909a.jpg, that shows how
the new, 4-window mmj2 Proof Assistant system can be arranged
on a large/widw physical As previously mentioned, in the
follow-on release, the user's positioning and sizing of windows
will be (it is planned) saved for use during the next execution
of mmj2 (aka "Persistent Storage Of User Preferences".)


P.S. Due to coding difficulties with the Search Results
window I added the following RunParms to RunParms.txt
in the TESTmmj2jar.zip file:

StepSelectorDialogPaneWidth,600
StepSelectorDialogPaneHeight,400

Adjust those rather than manually dragging window frames --
the settings last longer than one search :-)


=========================================================
6-Sep-2012

TESTmmj2jar.zip:

Unzip and double-click on mmj2.bat.

- If you like, in Windows, manually create a
desktop shortcut to mmj2.bat for convenience.

- In OSX or Linux just plop the
TESTmmj2jar\mmj2.jar into your regular
environment, temporarily of course, haha...

Future test versions will be named the same and I
will re-upload new versions of TESTmmj2jar.zip
whenever.

* * *

About It --> TESTmmj2jar.zip

This is simply the test environment mmj2\mmj2jar
directory with no updates other than the new
code.

This is a VERY notable version of the Search
Enhancement: it delivers a 'system' that is merely
missing several features:

Missing Features:

* 'New:' button
* Search Data fields (all)
* Extended Search (all)
* ExclLabels:
* MaxTime:
* AutoSelect:

WARNING: the code is largely untested. It almost
certainly has bugs, perhaps dramatic bugs :-)
The purpose of releashing this thing now is just
to let you play with it and see how it looks.

NOTE: The new Search menu on the ProofAsstGUI
navigates you to the new Search windows. Meanwhile,
the right-mouse button popup menu contains the new
'Search Options', 'Step Search' and 'General Search'
options -- in addition to the old 'Step Selector'.
Double-clicking a derivation proof step takes you
to the old, Step Selector.

What this boils down to is that you can compare
the new Search Results to the old Step Selector
Dialog search results -- and the new Search lets you
do everything the old, Step Selector does, including
'Apply'ing a search result to update the originally
designated derivation step for unification!

CHANGE MADE: The 'Print' button was removed from the
Search Options and Search Results windows. Instead,
print functionality was rolled-into the 'Stats' option,
which is now an integer from 0 thru 999. Choose level
4 or higher and the Search Results are printed.

P.S. For now, 'Stats' just print to the command prompt
window.