http://us2.metamath.org:88/ocat/mmj2/TESTmmj2jar.zip

9-Sep-2012

I am just prepending this README.txt to the 6-Sep version
as there are only a few changes -- but they are pretty big.

1) Search Options MaxTime and ExclLabels are now operational!
It turned out that MaxTime required only a dozen lines of
code and ExclLabels was easy enough to code using Regular
Expressions to convert the Metamath search label specifiers
into Regular Expressions!

This leaves only the following Search Options fields inoperative:

- Search Data: all

- Search Controls:

     - Extended Search: all

     - AutoSelect.


2) Search Option 'Stats' now generates output to the
Request Messages window. This is an existing Proof Assistant
window that has historically been forgotten, partly because
it tends to hide behind the ProofAsstGUI frame. Now it
demonstrates its utility as a place to dump large amounts
of data resulting from search requests! (Stats data will be
available in RunParm command output as well -- just not yet.)

I enclosed a file, ScreenDump20120909a.jpg, that shows how
the new, 4-window mmj2 Proof Assistant system can be arranged
on a large/widw physical As previously mentioned, in the
follow-on release, the user's positioning and sizing of windows
will be (it is planned) saved for use during the next execution
of mmj2 (aka "Persistent Storage Of User Preferences".)


P.S. Due to coding difficulties with the Search Results
window I added the following RunParms to RunParms.txt
in the TESTmmj2jar.zip file:

StepSelectorDialogPaneWidth,600
StepSelectorDialogPaneHeight,400

Adjust those rather than manually dragging window frames --
the settings last longer than one search :-)


=========================================================
6-Sep-2012

TESTmmj2jar.zip:

Unzip and double-click on mmj2.bat.

- If you like, in Windows, manually create a
desktop shortcut to mmj2.bat for convenience.

- In OSX or Linux just plop the
TESTmmj2jar\mmj2.jar into your regular
environment, temporarily of course, haha...

Future test versions will be named the same and I
will re-upload new versions of TESTmmj2jar.zip
whenever.

* * *

About It --> TESTmmj2jar.zip

This is simply the test environment mmj2\mmj2jar
directory with no updates other than the new
code.

This is a VERY notable version of the Search
Enhancement: it delivers a 'system' that is merely
missing several features:

Missing Features:

* 'New:' button
* Search Data fields (all)
* Extended Search (all)
* ExclLabels:
* MaxTime:
* AutoSelect:

WARNING: the code is largely untested. It almost
certainly has bugs, perhaps dramatic bugs :-)
The purpose of releashing this thing now is just
to let you play with it and see how it looks.

NOTE: The new Search menu on the ProofAsstGUI
navigates you to the new Search windows. Meanwhile,
the right-mouse button popup menu contains the new
'Search Options', 'Step Search' and 'General Search'
options -- in addition to the old 'Step Selector'.
Double-clicking a derivation proof step takes you
to the old, Step Selector.

What this boils down to is that you can compare
the new Search Results to the old Step Selector
Dialog search results -- and the new Search lets you
do everything the old, Step Selector does, including
'Apply'ing a search result to update the originally
designated derivation step for unification!

CHANGE MADE: The 'Print' button was removed from the
Search Options and Search Results windows. Instead,
print functionality was rolled-into the 'Stats' option,
which is now an integer from 0 thru 999. Choose level
4 or higher and the Search Results are printed.

P.S. For now, 'Stats' just print to the command prompt
window.