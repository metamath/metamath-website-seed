 $( $t
  htmldef "mychar" a "mychareplacement";
 $)
 
