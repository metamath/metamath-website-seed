 $( $t
  htmldef "" as "mychareplacement";
 $)
 
