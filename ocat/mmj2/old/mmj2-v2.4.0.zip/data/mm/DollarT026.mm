 $( $t 
  htmldef "ph" as "phi";
    althtmldef "ph" as "altphi";
  htmldef "ps" as "psi";
    althtmldef "ph" as "altpsi";
  htmldef "ch" as "chi";
    althtmldef "ph" as "altchi";
  
 $)
 
