 $( $t
  htmldef "mychar" as ""; 
 $)
 
