 $( $t
  htmldef          as "mychareplacement" x;
 $)
 
