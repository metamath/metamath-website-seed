${
    $d x z $.
    ax-2 $a |- ( x , y , z ) $.
$}

