$( E-LA-0001 Constants must be defined in outer/global
             scope level. $)
${ $c c $. $}

$( E-LA-0002 Too many End Scope statements? Cannot end
             global level!"  $)
${ $( level1 $) $} $}

$( E-LA-0003 Missing End Scope? EOF reached following
             Begin Scope! $)
${

