$c |- wff $. $( <--need these for Grammar Constructor, OR
                specify RunParmFile param entries:
                    ProvableLogicStmtType,|-
                    LogicStmtType,wff
             $)

$( NOTE: FOLLOWING EDITS, INCLUDING E-GR-0005 ARE PERFORMED ONLY
         IF PREVIOUS GRAMMAR EDITS ARE SUCCESSFUL. $)

$( E-GR-0005 Parsed Formula's expression contains Constant ";
             " that is used elsewhere as a Grammatical Type"
             " (VarHyp Type, Syntax Axiom Type, Logic Stmt"
             " Type or Provable Logic Stmt Type)."; $)
$c c511 c521 $.
a511 $a c511 $.
p521 $p c521 c511 $= ? $.
