$( E-IO-0019 Statement has duplicate tokens."
             Statment keyword = $)
$c c c $.
$v v v $.
$d v v $. 

$( E-IO-0020 Statement incomplete, end of file reached"
        + " while reading tokens. Statment keyword = $)
$c

