 $( $t
  htmldef "mychar" as  mychareplacement";
 $)
 
