$( public static final String ERRMSG_INV_INPUT_CHAR =
   "A-IO-0001 Invalid input character, decimal value = "; $)
�

