$( ParsingBook7dot1Pg146.mm $)

$c |- wff    $.
$c S A B     $.

$v s a b     $.
$v a1 a2 a3  $.

Vs  $f S s   $.
Va  $f A a   $.
Va1 $f A a1  $.
Va2 $f A a2  $.
Va3 $f A a3  $.
Vb  $f B b   $.

R1 $a S a s b    $.
R2 $a S s a b    $.
R3 $a S a1 a2 a3 $.

T1 $p S a a1 a2 a3 b              $= ? $.
T2 $p S a a s a b b b a b a b a b $= ? $.     

