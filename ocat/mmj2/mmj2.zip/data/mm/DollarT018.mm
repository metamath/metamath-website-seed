 $( $t
  htmldef "mychar" as "" + "mychar"
  + "eplacement" + ; 
 $)
 
