$( E-IO-0003 Invalid keyword read =  $)
$z

$( E-IO-0004 Constant statement ($c) with no constants read $)
$c $.

$( E-IO-0005 Invalid character in Math Symbol. Symbol read = $)
$c $ $.
 
$( E-IO-0006 Variable statement ($v) with no variables read $)
$v $. 

$( E-IO-0007 Fewer than 2 disjoint variables in $d statement. $)
${ $( $v a b $. $) $d $. $)

$( E-IO-0008 Label missing for keyword = $)
$a

$( E-IO-0009 End Comment keyword ".." without matching Start Comment "..". $)
$)

$( E-IO-0010 Invalid character in Label, token read = $)
+ $a $.

$( E-IO-0011 Prohibited Label (no device name such as NUL, LPT1, CON, etc.) = $)
LPT1 $a $.

$( E-IO-0012 Premature End of File following Label = $)
label


