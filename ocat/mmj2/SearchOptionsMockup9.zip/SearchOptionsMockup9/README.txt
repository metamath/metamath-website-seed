=========================================================
20-Aug-2012

SearchOptionsMockup9:

-  unzip SearchOptionsMockup9.zip.

-  There are two different mockup versions to try:

   Mockup9StepSearch.bat

   and

   Mockup9GeneralSearch.bat

   just double-click to run...


-  Version 9 of the Search Options mockup is different from
   Version 8 in just one way:

    1. The ChapSecHierarchy option has been revised to give
       the user more control.

       - Either direct or indirect
       relationships can be used to define the hierarchies.

       - Also, relationships are now based solely on proofs.
       Previously every symbol and statement reference was
       counted as a 'dependency'. However, based on discussion
       with Norm, I decided to use adhere closely to the
       Metamath.exe approach.


       NOTE: I am including a test version of set.mm with Chapter
       and Section titles describing the references in those
       Chapters and Sections:

            TSvcChapSecStuffTest1.mm

       Test output from a special 'unit test' is also included:

            TSvcChapSecStuffTest1Output1b.txt


       The ChapSecHierarchy Help text is included below.


---------------------
| ChapSecHierarchy: |
---------------------

The purpose of the ChapSecHierarchy option is to preemptively eliminate
irrelevant assertions from the Search Results:

* If 'On' the ChapSecHierarchy option restricts the search domain to
assertions belonging to the defined hierarchy of Chapters or Sections.

* Hierarchies are based on the proof relationships of theorems in a Chapter
or Section to theorems and axioms defined in other Chapters or Sections --
plus, by definition, for the convenience of Search Options users, a
Chapter or Section is always related to itself.


The options are are follows:

* blank = turn off ChapSecHierarchy feature

* Chap/Direct = Granularity of hierarchies is at the Metamath Chapter level;
  and hierarchies are restricted to direct proof relationships between
  Chapters.

* Chap/Indir. = Granularity of hierarchies is at the Metamath Chapter level;
  and hierarchies include both direct and indirect proof relationships
  between Chapters.

* Sec/Direct = Granularity of hierarchies is at the Metamath Section level;
  and hierarchies are restricted to direct proof relationships between
  Sections.

* Sec/Indir. = Granularity of hierarchies is at the Metamath Section level;
  and hierarchies include both direct and indirect proof relationships
  between Sections.


Either one or two hierarchies can be specified; if two are specified then
their set union is used -- that is, a composite hierarchy is used.

* Hierarchy 1 has as root (or apex) the Chapter or Section of the Theorem/
  Stmt/LOC_AFTER of the search;

* Hierarchy 2 has as root the ThruChap or ThruSec Chapter or Section.


The FromChap, FromSec, ThruChap and ThruSec fields are used to 'clip' the
lower and upper endpoints hierarchy ranges:

* The lower endpoint of the hierarcies' range of Chapters or Sections is given
  by FromChap or FromSec, respectively; if both are blank then the low end of
  the hiararchies is the start of the database.

* The upper endpoint of the hierarchies is given by the Chapter or Section of
  the Theorem/Stmt/LOC_AFTER and the ThruChap or ThruSec, whichever is lower.


A global search, with blank Theorem/Stmt/LOC_AFTER, and blank ThruChap and
ThruSec effectively disables the ChapSecHierarchy option.



