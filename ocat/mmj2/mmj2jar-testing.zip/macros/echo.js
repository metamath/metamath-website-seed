var array = Java.from(args);
array.shift();
log(array.join(" "));