if (executionMode == ExecutionMode.WORKSHEET_PARSE) {
	proofWorksheet = macroStmt.proofWorksheet;
	messages = proofWorksheet.messages;
	argsRaw = macroStmt.stmtText.toString();
}
