=========================================================
26-Aug-2012

TESTmmj2jar.zip:

Unzip and double-click on mmj2.bat.

- If you like, in Windows, manually create a
desktop shortcut to mmj2.bat for convenience.

- In OSX or Linux just plop the
TESTmmj2jar\mmj2.jar into your regular
environment, temporarily of course, haha...

Future test versions will be named the same and I
will re-upload new versions of TESTmmj2jar.zip
whenever.

* * *

About It --> TESTmmj2jar.zip

This is simply the test environment mmj2\mmj2jar
directory with no updates other than the new
code.

This is a notable version of the Search
Enhancment "mockup": the SearchOptions window has
been integrated into mmj2. Of primary interest
this allows us to see how the screen navigation
works -- and to envision how it will work when
the SearchResults window is added.

(NOTE: the existing "Step Selector Search"
feature is still in the ProofAsstGUI -- no change
to it whatsoever. Later it will be removed and
double- clicking a derivation proof step will
invoke the new Search in Step Search mode.)

The "screen navigation" issue boils down to this
problem: if you have a large and wide screen
(monitor) then you will be able to simultaneously
display all of the key mmj2 windows --
ProofAsstGUI, SearchOptions and SearchResults,
plus the RequestMessages window if you are so
inclined (this window will be useful with Search
if the Stats option is 'On' because statistics
about each search will be output to
RequestMessages.)

After mmj2 displays each window you can move it
where you want on the screen. So, With a wide
screen clicking one the the buttons to "jump" to
another window will just mean a change of
keyboard "focus" (which window responds to
keyboard actions.)

With a small/narrow screen however, the mmj2
windows will overlap, partly or completely (as
would happen on a large screen if you "maximized"
each window.) In this case, "jumping" to a
different window will cause mmj2 to put the
desired window on the top of the display stack --
the previously displayed window will still exist
but it will be obscured.

* * *

Another key thing about this test version: a
"Search" menu has been added to the ProofAsstGUI
window, and several of the Search menu items have
been added to the right-mouse button popup
window: Search Options, Step Search, and General
Search.

The way these menu items work is simple, yet
worth explaining the first time:

- if you choose Step Search the mouse cursor must
be positioned on a derivation proof step (not one
of the theorem's hypotheses). That will take you
into "Step Search mode" and execute the search
without displaying the Search Options window. As
yet the actual search has not been coded, right
now you just see a popup error message.

- if you choose General Search it doesn't matter
where the mouse cursor is, you will be taken to
the Search Options window in "General Search
mode".

- if you choose Search Options then the Search
Options window will be displayed and the mode
will be based on the mouse cursor position: if it
is on a derivation step the mode will be "Step
Search mode", otherwise it will be "General
Search mode". (On the Search Options window it is
possible to switch from Step Search mode to
General Search mode using the New button.)

* * *

ALSO, and this is nice, now that Search Options
is connected to mmj2 the From/Thru Chap/Sec
pulldown lists display the actual Chapters and
Sections from the loaded .mm file(s) (assuming
you haven't disabled BookManager.)

* * *

The plan going forward is fluid but I think it
will be as follows -- and you will be able to
test after each step:

1. Clone the Step Selector Dialog as the new
   Search Results window. I will recode it using
   the methods and techniques developed for
   Search Options so that it has the same "look
   and feel" for both users and programmers.
   (Step Selector Dialog only has 242 lines and
   changing to the new code style will be worth
   it.)

2. Implement the existing search algorithms of
   Step Selector Search as the new Search.
   Everything you can do with Step Selector
   Search you will be able to do with the new
   Search, including updating proof steps.

   In addition, the Search Options "Exclusion
   Criteria" Search Controls will be operational
   as well as the Output Controls MaxTime,
   Substitutions, Comments, Stats and OutputSort.
   What won't be done in #2 are Extended Search,
   AutoSelect or Search Data.

3. Implement the Extended Search.

4. Implement the Search Data features.

5. Implement AutoSelect (saving the tricky part
   for last...#3 is The Good, #4 The Bad, and #5
   The Ugly.)

6. Implement batch RunParms for testing.

7. Next release (in 2013), Persistent Storage of
   User Preferences.

* * *
